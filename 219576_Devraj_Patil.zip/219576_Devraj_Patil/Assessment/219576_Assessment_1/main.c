#include <LPC17xx.h>

#include <stdint.h>

#define ALL_LED_PINS (0x0F << 19)

void delay(uint32_t );
void timer1_delay_us(unsigned int );


int main(void)
{


//timer1_init();  
	
LPC_GPIO1->FIODIR |= ALL_LED_PIN(24);
	
timer1_delay_us(1000);
                                      
while(1)								  	
{
if(LPC_TIM1->IR & (1<<0))
{
LPC_GPIO1->FIOPIN ^= ALL_LED_PIN(24);
LPC_TIM1->IR = 1<<0;
}
}



LPC_GPIO1 -> FIODIR |= ALL_LED_PINS;

while(1)
{
LPC_GPIO1 -> FIOSET = ALL_LED_PINS;
delay(1000);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS; 
delay(1000);
}

return 0;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
 k++ ;
}

}
 return ; 
}


void timer1_init(void)
{
	LPC_SC->PCONP |= (1 << 2); 
	LPC_SC->PCLKSEL0 |=(0x01 << 4);
	LPC_TIM1->CTCR = 0x00;
	LPC_TIM1->PR = 2;  
    LPC_TIM1->TCR = (1<<1);
	LPC_TIM1->MCR |= (1<<1)|(1<<0);
}



void timer1_delay_us(unsigned int us)
{
   	LPC_TIM1->MR0 = us;
	LPC_TIM1->TCR =(1<<0);
}



