#include <LPC17xx.h>
#include <stdio.h>
#include <stdint.h>
#include "lcd.h"
#include "uart.h"

#define CAN2_BAUD_RATE 200000  

#define CAN1_BAUD_RATE 200000  

void CAN2_Init(void);
void CAN1_Init(void);

void CAN2_MessageSend(uint32_t msgId, uint64_t data, uint8_t length);
void CAN1_MessageReceive(uint32_t *msgId, uint64_t *data, uint8_t *length);

int main(void)
{
    uint32_t tmsgId = 0x0;
    uint64_t tmessageData = 0x219576;
    uint8_t  tlength = 3; 
    
    uint32_t rmsgId;
    uint64_t rmessageData;
    uint8_t  rlength;  
    

    char id_data[20];


    lcd_init();
	   uart_config();


    CAN2_Init();    
    CAN1_Init();    
 
    while (1) 
    {
        CAN2_MessageSend(tmsgId, tmessageData, tlength);
        
        sprintf(id_data,"%x %llx",tmsgId,tmessageData);
        lcd_str_write(id_data);
        lcd_cmd_write(0xC0);
        //lcd_str_write("EMP ID Txted");
		uart_str_transmit("EMP ID Txted");

        delay(1000);
        lcd_cmd_write(0x01);

        CAN1_MessageReceive(&rmsgId, &rmessageData, &rlength);
        

        sprintf(id_data,"%x %llx",rmsgId,rmessageData);
        lcd_str_write(id_data);
        lcd_cmd_write(0xC0);
        //lcd_str_write("EMP ID Received");
		uart_str_transmit("EMP ID Received");
        delay(1000);
        lcd_cmd_write(0x01);
    }
}


void CAN2_Init(void) 
{

    LPC_PINCON->PINSEL4 |=  (1 << 14);
    LPC_PINCON->PINSEL4 &= ~(1 << 15);
    LPC_PINCON->PINSEL4 |=  (1 << 16);
    LPC_PINCON->PINSEL4 &= ~(1 << 17);
    
    LPC_SC->PCONP |= (1 << 14);
    

    LPC_CAN2->MOD = 1;
    

    LPC_CAN2->BTR = (1<<23)|(2<<20)|(0<<16)|(0X00); 

    LPC_CAN2->MOD = 0;
}


void CAN2_MessageSend(uint32_t msgId, uint64_t data, uint8_t length) 
{

    while((LPC_CAN2->GSR & (1 << 2)) == 0){ }
    

    LPC_CAN2->TID1 = msgId;
    
 
    if(msgId > 0x7FF)
    {
        LPC_CAN2->TFI1 |= (1U << 31);
    }

    LPC_CAN2->TFI1 |= ((uint32_t)length << 16);


    if(length > 4)
    {
        LPC_CAN2->TDB1 = data >> 32;
    }
    
    LPC_CAN2->TDA1 = (uint32_t)data;
    
 
    LPC_CAN2->CMR |= (1 << 0)|(1 << 5);

    while ((LPC_CAN2->GSR & (1 << 3)) == 0) { }
}

void CAN1_Init(void) 
{

    LPC_PINCON->PINSEL0 |= (1 << 0);
    LPC_PINCON->PINSEL0 &= ~(1 << 1);
    LPC_PINCON->PINSEL0 |= (1 << 2);
    LPC_PINCON->PINSEL0 &= ~(1 << 3);
    
 
    LPC_SC->PCONP |= (1 << 13);
    

    LPC_CAN1->MOD = 1;
    

    LPC_CAN1->BTR = (1<<23)|(2<<20)|(0<<16)|(0X00); 
 
    LPC_CAN1->MOD = 0;
}

void CAN1_MessageReceive(uint32_t *msgId, uint64_t *data, uint8_t *length) 
{

    while((LPC_CAN1->GSR & (1<<0))==1){ }

    *msgId = LPC_CAN1->RID;

    *length = (LPC_CAN1->RFS >> 16) & 0x0F ;

    *data = LPC_CAN1->RDA;

    if(*length > 4)
    {
        *data = *data | ((uint64_t)LPC_CAN1->RDB << 32);
    }
    LPC_CAN1->CMR=(1<<2);
}



						  

    