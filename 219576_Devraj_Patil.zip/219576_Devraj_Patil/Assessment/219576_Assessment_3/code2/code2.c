#include <lpc17xx.h>

#define LCD_DATA_PINS (0xFF << 15)
#define LCD_RS_PIN(X) (1 << X)
#define LCD_EN_PIN(X) (1 << X)

void delay(unsigned int a)
{
    unsigned int i, j;
    for (i = 0; i < a; i++)
        for (j = 0; j < 6000; j++)
            ;
}

void uart_config()
{
    LPC_SC->PCONP |= 0x00000008;
    LPC_PINCON->PINSEL0 = 0x00000050;
    LPC_UART0->LCR = 0x00000083;  
    LPC_UART0->DLM = 0X00;
    LPC_UART0->DLL = 0x1A;        
    LPC_UART0->LCR = 0x00000003;
    LPC_UART0->FCR = 0X07;  
}

void uart_data(unsigned char d)
{
    while (!(LPC_UART0->LSR & (1 << 5)));
    LPC_UART0->THR = d;                  
    delay(10);
}

void uart_str(unsigned char *ptr)
{
    while (*ptr != '\0')
    {
        uart_data(*ptr);
        ptr++;
    }
}

unsigned char uart_rx()
{
    while (!(LPC_UART0->LSR & (1 << 0)));
    return LPC_UART0->RBR;
}

void uart_num(unsigned int num)
{
    if (num)
    {
        uart_num(num / 10);
        uart_data(num % 10 + 0x30);
    }
}


// --------------------------------------------------------------- main
int main()
{
char z;
int i;
uart_config();
uart_str("Key Pressed : \n");
LPC_GPIO1 -> FIODIR |= (0xFF<<19);
LPC_GPIO1 -> FIODIR |= (1<<27);
LPC_GPIO1 -> FIODIR |= (1<<28);
 
while(1)
{
z = uart_rx();
switch(z){
case 'Y':
//first blink
for(i = 0; i<2; i++){
LPC_GPIO1 -> FIOSET |= (0x01 << 19);
delay(200);
LPC_GPIO1 -> FIOCLR |= (0x01 << 19);
delay(200);
}
break;
case 'N':
//last blink
for(i = 0; i<2; i++){
LPC_GPIO1 -> FIOSET |= (0X80<< 19);
delay(200);
LPC_GPIO1 -> FIOCLR |= (0X80 << 19);
delay(200);
}
break;
case '9':
//led off
delay(200);
break;
}
uart_data(z);
}
}

