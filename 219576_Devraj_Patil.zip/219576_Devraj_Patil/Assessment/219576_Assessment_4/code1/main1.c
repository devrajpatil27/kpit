#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "uart.h"		

static void Task1(void* pvParameters);
static void Task2(void* pvParameters);

xTaskHandle t1;
xTaskHandle t2;
xSemaphoreHandle xSemaphore = NULL;
#define LED_PORT LPC_GPIO1->FIOPIN

int main(void)
{
	SystemInit();		
	uart_init();			
	LPC_GPIO1->FIODIR |= 0xff << 19; //making all led pins as output
	LPC_GPIO1->FIODIR |= (1<< 27); // making buzzer as output
    xSemaphore = xSemaphoreCreateMutex();//creating semaphore
	if(xSemaphore != NULL)
	 {
		uart_printf("Semaphore got created and went into Task1");
		xTaskCreate( Task1, "Task1", configMINIMAL_STACK_SIZE, NULL, 1, &t1 );//creating task1
		vTaskStartScheduler();// scheduling the task1
	 }
	else
		uart_printf("\n\rFailed to create Semaphore");

	while(1);

	return 0;
}


static void Task1(void* pvParameters)
{
	uart_printf("\n\rIn Task1");
	uart_printf("\n\rTask1 got Semaphore Access");
	xSemaphoreTake(xSemaphore,portMAX_DELAY); // to access the semaphore to task1
	uart_printf("\n\rIn Task1 I am Creating Task2");
	xTaskCreate( Task2, "Task2", configMINIMAL_STACK_SIZE, NULL, 3, &t2 ); //to create task2
	uart_printf("\n\rBack in Task1 I will complete Task1");// came back from task1 and ding task1 operations
	LPC_GPIO1->FIOSET=(1<<19);// only 1 led get on and off
		delay_ms(1000);
	LPC_GPIO1->FIOCLR=(1<<19);
		delay_ms(1000);
	LPC_GPIO1->FIOSET=(1<<27);// buzzer makes small sound
		delay_ms(100);
	LPC_GPIO1->FIOCLR=(1<<27);
		delay_ms(100);
	uart_printf("\n\rTask1 Released Semaphore");   // releasing semaphore from task1
	xSemaphoreGive(xSemaphore);
	vTaskDelete(t1);
}

static void Task2(void* pvParameters)
{
	uart_printf("\n\rIn Task2,it has high priority than Task1 trying to get the semaphore Access\n\rBut can't get access as Semaphore key is with Task1");
	xSemaphoreTake(xSemaphore,portMAX_DELAY); //got semaphore access for task2
	uart_printf("\n\rIn Task2, after task1 released semaphore key I got the semaphore");
	LPC_GPIO1->FIOSET=(0xFF<<19);// to set all leds
		delay_ms(1000);
	LPC_GPIO1->FIOCLR=(0xFF<<19);
		delay_ms(1000);
	LPC_GPIO1->FIOSET=(1<<27);	 // to set buzzer for long time
		delay_ms(1000);
	LPC_GPIO1->FIOCLR=(1<<27);
		delay_ms(1000);
	uart_printf("\n\rIn Task2,I am releasing the semaphore");
	xSemaphoreGive(xSemaphore); // to release semaphore
	vTaskDelete(t2);
}











































