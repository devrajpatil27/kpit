/* Scheduler include files. */
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "uart.h"
		
#define MaxQueueItems 3
#define QueueItemSize 20

static void MyTaskB(void* pvParameters);
static void MyTaskA(void* pvParameters);

xTaskHandle TaskHandle_B;
xTaskHandle TaskHandle_A;

xQueueHandle MyQH;

#define LED_TaskB   (0x02u << 19)
#define LED_TaskA   (0x04u << 19)

#define LED_PORT LPC_GPIO1->FIOPIN

int main(void)
{
	SystemInit();		
	uart_init();		
	LPC_GPIO1->FIODIR |= 0xff << 19;

	MyQH = xQueueCreate(MaxQueueItems,QueueItemSize);	

	if(MyQH != 0)
	{
		uart_printf("\n\rQueue Created");

		xTaskCreate( MyTaskB, "TaskB", configMINIMAL_STACK_SIZE, NULL, 1, &TaskHandle_B );
		xTaskCreate( MyTaskA, "TaskA", configMINIMAL_STACK_SIZE, NULL, 2, &TaskHandle_A );

		vTaskStartScheduler();	
	}
	else
		uart_printf("\n\rQueue not Created");

	while(1);

	return 0;
}


static void MyTaskB(void* pvParameters)
{
	char RxBuffer[QueueItemSize];
	
	LED_PORT = LED_TaskB;	

	uart_printf("\n\rTask B, Reading the data from queue");
	
	if(pdTRUE == xQueueReceive(MyQH,RxBuffer,100000))
	{
			 
		uart_printf("\n\rBack in task B, Received data : ");
		uart_printf(RxBuffer);
		LED_PORT = LED_TaskB;

	}
	else
	{
		LED_PORT = LED_TaskB;	  
		uart_printf("\n\rBack in task B, No Data received:");
	}

	vTaskDelete(TaskHandle_B);
}


static void MyTaskA(void* pvParameters)
{
	char TxBuffer[QueueItemSize]={"led on"};
	
	LED_PORT = LED_TaskA;	  

	uart_printf("\n\rTask A, Filling the data onto queue");
	
	if(pdTRUE == xQueueSend(MyQH,TxBuffer,100000))
	{
		LED_PORT = LED_TaskA;	 
		uart_printf("\n\rSuccessfully sent the data :");
		uart_printf(TxBuffer);
	}
	else			 
	{
		LED_PORT = LED_TaskA;	 
		uart_printf("\n\rSending Failed");
	}

	uart_printf("\n\rExiting task A");
	vTaskDelete(TaskHandle_A);
}