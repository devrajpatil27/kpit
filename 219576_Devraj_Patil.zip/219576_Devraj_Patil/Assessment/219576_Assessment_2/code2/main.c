#include <LPC17xx.h>
#include <stdint.h>


void timer3_config(void);
void timer3_int_config(void);

void delay(int n){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<3000;j++);
	}
}

int main() {
LPC_GPIO1->FIODIR |= (1 << 19);    // Configure P1.19 as output


timer3_config();
timer3_int_config();

while (1) {
LPC_GPIO1->FIOSET |= (1 << 19);
delay(100);

LPC_GPIO1->FIOCLR |= (1 << 19);
delay(100);
}
}

void timer3_config(void) {
LPC_SC->PCONP |= (1 << 23);    // Power up Timer3

LPC_TIM3->PR = 14;             // Set the prescaler value
LPC_TIM3->MR0 = 5000000;       // Set match register for 5 seconds delay
LPC_TIM3->MCR = (1 << 0) | (1 << 1);  // Interrupt and Reset on Match0
LPC_TIM3->TCR = 1 << 1;        // Reset Timer3
LPC_TIM3->TCR = 1;              // Enable Timer3
}

void timer3_int_config(void) {
NVIC_ClearPendingIRQ(TIMER3_IRQn);     // Clear pending interrupts for Timer3
NVIC_SetPriority(TIMER3_IRQn, 1);      // Set priority for Timer3 interrupt
NVIC_EnableIRQ(TIMER3_IRQn);           // Enable Timer3 interrupt
}

void TIMER3_IRQHandler(void) {
    
LPC_GPIO1->FIOPIN ^= (1 << 19);  // Toggle P1.19 state
LPC_TIM3->IR = 1 << 0;                 // Clear interrupt flag
NVIC_ClearPendingIRQ(TIMER3_IRQn);     // Clear pending interrupt for Timer3
}

