
#include <stdio.h>

// Function to perform bubble sort on an array
void bubble_sort(int myArray[], int n) {
    // Outer loop to traverse the entire array
    for (int i = 0; i < n-1; i++) {
        // Inner loop to compare and swap elements
        for (int j = 0; j < n-i-1; j++) {
            // If the current element is greater than the next element, swap them
            if (myArray[j] > myArray[j+1]) {
                int temp = myArray[j];
                myArray[j] = myArray[j+1];
                myArray[j+1] = temp;
            }
        }
    }
}

// Improved bubble sort with optimization to stop if no swaps are made in a pass
void bubble_sort_optimized(int myArray[], int n) {
    // Outer loop to traverse the entire array
    for (int i = 0; i < n-1; i++) {
        int swapped = 0; // flag to check if any swaps were made
        // Inner loop to compare and swap elements
        for (int j = 0; j < n-i-1; j++) {
            // If the current element is greater than the next element, swap them
            if (myArray[j] > myArray[j+1]) {
                int temp = myArray[j];
                myArray[j] = myArray[j+1];
                myArray[j+1] = temp;
                swapped = 1; // set flag to true
            }
        }
        // If no two elements were swapped by inner loop, the array is sorted
        if (swapped == 0)
            break;
    }
}

// Further optimized bubble sort with a flag to break early if no swaps are made
void bubble_sort_further_optimized(int myArray[], int n) {
    int swap;
    // Outer loop to traverse the entire array
    for (int i = 0; i < n-1; i++) {
        swap= 0; // flag to check if any swaps were made
        // Inner loop to compare and swap elements
        for (int j = 0; j < n-i-1; j++) {
            // If the current element is greater than the next element, swap them
            if (myArray[j] > myArray[j+1]) {
                int temp = myArray[j];
                myArray[j] = myArray[j+1];
                myArray[j+1] = temp;
                swap = 1; // set flag to true
            }
        }
        // If no swaps were made, the array is sorted, and we can break early
        if (swap== 0)
            break;
    }
}

// Main function
int main()
{
    int i = 0;
    // Sample array to be sorted
    int myArray[] = {64, 34, 25, 12, 22, 19, 90};
    int n = sizeof(myArray) / sizeof(myArray[0]);
    
    // Sorting the array using bubble_sort function
    bubble_sort(myArray, n);

    // Printing the sorted array
    printf("Sorted array:\n");
    for (i = 0; i < n; i++)
    {
        printf("%d\n", myArray[i]);
    }
    
    return 0;
}



