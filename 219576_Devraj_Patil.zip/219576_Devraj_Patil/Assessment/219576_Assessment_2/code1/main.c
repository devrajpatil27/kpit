#include <LPC17xx.h> // Include LPC17xx series microcontroller header file

void delay(int n){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<3000;j++);
	}
} // Function to create a simple delay using nested loops

void int_init(void){
	NVIC_ClearPendingIRQ(EINT3_IRQn);		
	NVIC_SetPriority(EINT3_IRQn,1);			
	NVIC_EnableIRQ(EINT3_IRQn);				

	LPC_SC -> EXTINT |= (1<<3);				
	LPC_SC -> EXTMODE |= (1<<3);			
	LPC_SC -> EXTPOLAR |= (0<<3);			

	LPC_PINCON -> PINSEL4 |= (1<<26);		
	LPC_PINCON -> PINSEL4 &= ~(1<<27);
} // Function to initialize external interrupt (EINT3) and corresponding settings

void EINT3_IRQHandler(void){
	LPC_GPIO1 -> FIOCLR |= (1<<19);
	LPC_GPIO1 -> FIOSET |= (1<<21);
	delay(1000);
	LPC_GPIO1 -> FIOCLR |= (1<<21);
	delay(1000);
	LPC_SC -> EXTINT |= (1<<1);				
	NVIC_ClearPendingIRQ(EINT3_IRQn);
} // Interrupt service routine (ISR) for external interrupt (EINT3)

int main(void){
	int_init(); // Initialize external interrupt settings
	LPC_GPIO1 -> FIODIR |= (1<<19); // Set pin 19 of GPIO1 as output
	while(1){
		LPC_GPIO1 -> FIOSET |= (1<<19); // Set pin 19 high
		delay(100);
		LPC_GPIO1 -> FIOCLR |= (1<<19); // Clear pin 19
		delay(100);
	}
} // Main function that initializes interrupt and creates a simple blinking effect
