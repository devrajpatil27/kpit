#include "LPC17xx.h"
  //SINGLE EDGE
void delay(int a) {
    int i, j;
    for (i = 0; i < a; i++)
        for (j = 0; j < 6000; j++);
}

int main() {
    int val;
	LPC_PINCON->PINSEL3 &= ~(1 << 4);// P1.18 as PWM1.1
    LPC_PINCON->PINSEL3 |= (1 << 5);

    LPC_PINCON->PINSEL3 &= ~(1 << 8);// P1.19 as PWM1.1
    LPC_PINCON->PINSEL3 |= (1 << 9);

	LPC_PINCON->PINSEL3 &= ~(1 << 10);// P1.18 as PWM1.1
    LPC_PINCON->PINSEL3 |= (1 << 11);


	LPC_PINCON->PINSEL3 &= ~(1 << 14);// P1.18 as PWM1.1
    LPC_PINCON->PINSEL3 |= (1 << 15);

    LPC_PINCON->PINSEL3 &= ~(1 << 16);// P1.19 as PWM1.1
    LPC_PINCON->PINSEL3 |= (1 << 17);

	    LPC_PINCON->PINSEL3 &= ~(1 << 20);// P1.19 as PWM1.1
    LPC_PINCON->PINSEL3 |= (1 << 21);

	LPC_SC->PCONP |= (1 << 6); //PWM1.1 power/clk control enabled
	LPC_SC->PCLKSEL0 &=~(3<< 12); // Make 12 and 13 bit 0 

    LPC_PWM1->PR = 3;    // PR = 3, PCLK / (PR + 1) = 1MHz / (3+1) = 0.25MHz 
    LPC_PWM1->MR0 = 10000;             // Total period PWM cycle = 40ms
    LPC_PWM1->MCR |= (1 << 1);         // Reset on MR0
    LPC_PWM1->LER |= (1 << 0);         // Enable MR0 Latch

    LPC_PWM1->PCR |= (1 << 9);        // Enable PWM1 output  9=PWM1.1 10 =PWM1.2  
	LPC_PWM1->PCR |= (1 << 10);  
	LPC_PWM1->PCR |= (1 << 11);  
	LPC_PWM1->PCR |= (1 << 12);  
	LPC_PWM1->PCR |= (1 << 13);  
	LPC_PWM1->PCR |= (1 << 14); 

    LPC_PWM1->TCR = (1 << 0) | (1 << 3);  // Enable PWM Timer and PWM Mode

    while (1) {
        LPC_PWM1->MR1 = 2000;   // 20% duty cycle
        LPC_PWM1->LER |= (1 << 1);  // Enable MR1 Latch
        delay(1000);

        LPC_PWM1->MR2 = 4000;   // 40% duty cycle
        LPC_PWM1->LER |= (1 << 2);  // Enable MR1 Latch
        delay(1000);

        LPC_PWM1->MR3 = 8000;   // 80% duty cycle
        LPC_PWM1->LER |= (1 << 3);  // Enable MR1 Latch
        delay(1000);

		 LPC_PWM1->MR4 = 10000;   // 80% duty cycle
        LPC_PWM1->LER |= (1 << 4);  // Enable MR1 Latch
        delay(1000);

		 LPC_PWM1->MR5 = 12000;   // 80% duty cycle
        LPC_PWM1->LER |= (1 << 5);  // Enable MR1 Latch
        delay(1000);

		 LPC_PWM1->MR6 = 12000;   // 80% duty cycle
        LPC_PWM1->LER |= (1 << 6);  // Enable MR1 Latch
        delay(1000);
    }
}

