#include "LPC17xx.h"

void delay(int a) {
    int i, j;
    for (i = 0; i < a; i++)
        for (j = 0; j < 6000; j++);
}

int main() {
    LPC_PINCON->PINSEL4 &= ~(3 << 10); // Clear bits 10 and 11
    LPC_PINCON->PINSEL4 |= (1 << 10);  // P2.5 as PWM1.6

    LPC_PINCON->PINSEL4 &= ~(3 << 2); // Clear bits 2 and 3
    LPC_PINCON->PINSEL4 |= (1 << 2);  // P2.1 as PWM1.2


    LPC_PINCON->PINSEL4 &= ~(3 << 6); // Clear bits 6 and 7
    LPC_PINCON->PINSEL4 |= (1 << 6);  // P2.3 as PWM1.4




    LPC_SC->PCONP |= (1 << 6); //PWM1 power/clk control enabled
    LPC_SC->PCLKSEL0 &=~(1 << 12);

    LPC_PWM1->PR = 3;                // PCLK / (PR + 1) = 4MHz / (3+1) = 1MHz
    LPC_PWM1->MR0 = 10000;            // Total period of PWM cycle, 10ms
    LPC_PWM1->MCR |= (1 << 1);         // Reset on MR0
    LPC_PWM1->LER |= (1 << 0);         // Enable MR0 Latch

    LPC_PWM1->PCR |= (1 << 2);        // PWM6 as double edge
	LPC_PWM1->PCR |= (1 << 4);        // PWM2 as double edge
	LPC_PWM1->PCR |= (1 << 6);        // PWM4 as double edge

    LPC_PWM1->PCR |= (1 << 10);       // Enable PWM2
	LPC_PWM1->PCR |= (1 << 12);       // Enable PWM4
    LPC_PWM1->PCR |= (1 << 14);       // Enable PWM6

    LPC_PWM1->TCR = (1 << 0) | (1 << 3); // Start PWM timer and PWM output

    while (1) {
        LPC_PWM1->MR1 = 2000; // 10% duty cycle
        LPC_PWM1->MR2 = 3000;
        LPC_PWM1->LER = (1 << 2) | (1 << 1);
        delay(1000);

        LPC_PWM1->MR3 = 3000; // 30% duty cycle
        LPC_PWM1->MR4 = 6000;
        LPC_PWM1->LER = (1 << 4) | (1 << 3);
        delay(1000);

        LPC_PWM1->MR5 = 2000; // 70% duty cycle
        LPC_PWM1->MR6 = 9000;
        LPC_PWM1->LER = (1 << 6) | (1 << 5);
        delay(1000);
    }
}



//#include "LPC17xx.h"
//
//void delay(int a) {
//    int i, j;
//    for (i = 0; i < a; i++)
//        for (j = 0; j < 6000; j++);
//}
//
//int main() {
//    LPC_PINCON->PINSEL4 &= ~(3 << 8); // Clear bits 8 and 9
//    LPC_PINCON->PINSEL4 |= (1 << 8);  // P2.4 as PWM1.5
//
//
//    LPC_SC->PCONP |= (1 << 6); //PWM1 power/clk control enabled
//    LPC_SC->PCLKSEL0 &=~(1 << 12);
//
//    LPC_PWM1->PR = 3;                // PCLK / (PR + 1) = 4MHz / (3+1) = 1MHz
//    LPC_PWM1->MR0 = 10000;            // Total period of PWM cycle, 10ms
//    LPC_PWM1->MCR |= (1 << 1);         // Reset on MR0
//    LPC_PWM1->LER |= (1 << 0);         // Enable MR0 Latch
//
//    LPC_PWM1->PCR |= (1 << 5);        // PWM3 as double edge
//    LPC_PWM1->PCR |= (1 << 13);       // Enable PWM5
//
//    LPC_PWM1->TCR = (1 << 0) | (1 << 3); // Start PWM timer and PWM output
//
//    while (1) {
//        LPC_PWM1->MR4 = 2000; // 10% duty cycle
//        LPC_PWM1->MR5 = 3000;
//        LPC_PWM1->LER = (1 << 5) | (1 << 4);
//        delay(1000);
//
//        LPC_PWM1->MR4 = 3000; // 30% duty cycle
//        LPC_PWM1->MR5 = 6000;
//        LPC_PWM1->LER = (1 << 5) | (1 << 4);
//        delay(1000);
//
//        LPC_PWM1->MR4 = 2000; // 70% duty cycle
//        LPC_PWM1->MR5 = 9000;
//        LPC_PWM1->LER = (1 << 5) | (1 << 4);
//        delay(1000);
//    }
//}
//
