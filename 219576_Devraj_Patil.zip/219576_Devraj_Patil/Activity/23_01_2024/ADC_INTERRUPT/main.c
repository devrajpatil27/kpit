#include <lpc17xx.h>
#include "lcd.h"
#include "lcd.c"
#include "uart.h"
#define VREF       3.3 //Reference Voltage at VREFP pin, given VREFN = 0V(GND)
#define ADC_CLK_EN (1<<12)
#define SEL_AD0_1  (1<<1) //Select Channel AD0.1 
#define CLKDIV     (3 << 8)//ADC clock-divider (ADC_CLOCK=PCLK/CLKDIV+1) = 1Mhz @ 4Mhz PCLK
#define PWRUP      (1<<21) //setting it to 0 will power it down
#define START_CNV  (1<<24) //001 for starting the conversion immediately
#define ADC_DONE   (1U<<31) //define it as unsigned value or compiler will throw #61-D warning int m
#define EVEN_LED_PINS (0x55 << 19)
#define ODD_LED_PINS (0XAA << 19)

void int_config()
{
	NVIC_ClearPendingIRQ(ADC_IRQn);     // Clear pending interrupts for Timer0
    NVIC_SetPriority(ADC_IRQn, 1);      // Set priority for Timer0 interrupt
    NVIC_EnableIRQ(ADC_IRQn);           // Enable Timer0 interrupt 
	uart_str("Interrupts Config Done\r\n");  
}		

void ADC_IRQHandler()
{
	uart_str("Int occured\n");
	LPC_ADC->ADINTEN &= ~(1<<2);
	NVIC_ClearPendingIRQ(ADC_IRQn);
	LPC_GPIO1 -> FIOSET = EVEN_LED_PINS;
		LPC_GPIO1 -> FIOCLR = ODD_LED_PINS;
		delay(5);
		LPC_GPIO1 -> FIOSET = ODD_LED_PINS;
		LPC_GPIO1 -> FIOCLR = EVEN_LED_PINS;
		LPC_ADC->ADCR &= ~(START_CNV);

}

int main(void)
{


	LPC_PINCON->PINSEL1 |= (1<<16) ; //select AD0.1 for P0.24
	LPC_SC->PCONP |= ADC_CLK_EN; //Enable ADC clock
	LPC_ADC->ADCR =  PWRUP | CLKDIV | SEL_AD0_1;
	
	LPC_GPIO1 -> FIODIR |= EVEN_LED_PINS;
	LPC_GPIO1 -> FIODIR |= ODD_LED_PINS;

	//lcd_init();
	int_config();
	uart_config();	
	while(1)
	{
	uart_str(" now in main \n");
		LPC_ADC->ADINTEN |= (1<<2);
		 
		LPC_ADC->ADCR |= START_CNV; //Start new Conversion
		
	}
	
	return 0; //This won't execute
 }