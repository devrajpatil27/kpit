#include "lcd.h"

#define EVEN_LED_PINS (0x55 << 19)
#define ODD_LED_PINS (0XAA << 19)

void delay(uint32_t); 

int main1(void)
{
	LPC_GPIO1 -> FIODIR |= EVEN_LED_PINS;
	LPC_GPIO1 -> FIODIR |= ODD_LED_PINS;
	while(1)
	{
		LPC_GPIO1 -> FIOSET = EVEN_LED_PINS;
		LPC_GPIO1 -> FIOCLR = ODD_LED_PINS;
		delay(500);
		LPC_GPIO1 -> FIOSET = ODD_LED_PINS;
		LPC_GPIO1 -> FIOCLR = EVEN_LED_PINS; 
		delay(500);
	}
	
	return 0;
}
	
void delay1(uint32_t ms)
{
	uint32_t i,j,k;
	for(i = 0 ; i < ms ; i++)
	{
		k = 0 ;
		for(j = 0 ; j < 3000 ; j++)
		{
			 k++ ;
		}
	}
	return ; 
}