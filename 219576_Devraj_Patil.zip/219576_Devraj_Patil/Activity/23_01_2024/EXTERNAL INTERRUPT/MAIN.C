#include "LPC17xx.h"
#include <stdint.h>
#include "uart.h"
   //external interrupt
void int_config(void);

int main() {
    LPC_GPIO1->FIODIR |= (1 << 19);    // Configure P1.19 as output

    uart_config();                     // Initialize UART configuration
    int_config();                      // Initialize interrupt configuration

    while (1) {
        LPC_GPIO1->FIOSET |= (1 << 19);    // Set P1.19 high
        delay(100);
        LPC_GPIO1->FIOCLR |= (1 << 19);    // Clear P1.19 low
        delay(100);
    }
}

void int_config()
{
    NVIC_ClearPendingIRQ(EINT1_IRQn);
    NVIC_SetPriority(EINT1_IRQn, 1);      // Set priority for EINT1 interrupt
    NVIC_EnableIRQ(EINT1_IRQn);

    LPC_SC->EXTINT |= (1 << 1);           // Clear pending EINT1 interrupt
    LPC_SC->EXTMODE |= (1 << 1);          // Set EINT1 as edge-sensitive
    LPC_SC->EXTPOLAR &= ~(1 << 1);        // Set EINT1 to be sensitive to the falling edge
  
    LPC_PINCON->PINSEL4 &= ~(3 << 22);    // Clear bits 22 and 23
    LPC_PINCON->PINSEL4 |= (1 << 22);     // Set bits 22 for P2.11 as EINT1
    uart_str("EXT interrupt config done\r\n");
}

void EINT1_IRQHandler(void)
{
    uart_str("EXT interrupt occurred\r\n");  // Print message when EINT1 interrupt occurs
    delay(100);
    LPC_SC->EXTINT |= (1 << 1);           // Clear pending EINT1 interrupt
    NVIC_ClearPendingIRQ(EINT1_IRQn);     // Clear pending interrupt flag for EINT1
}













