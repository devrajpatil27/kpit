#include <LPC17xx.h>
#include <stdint.h>
#include "uart.h"
						 
void int_config(void);
 //Interrupt with 2 timers timer 0 and timer 1
void timer0_config(void);
void timer1_config(void);		 

int main() {
    LPC_GPIO1->FIODIR |= (1 << 19);    // Configure P1.19 as output
	LPC_GPIO1->FIODIR |= (1 << 20);
    uart_config();                     // Initialize UART configuration
    timer0_config();                   // Initialize Timer 0 configuration
	timer1_config();  					// Initialize Timer1 configuration
    int_config();                      // Initialize interrupt configuration

    while (1) {
        LPC_GPIO1->FIOSET |= (1 << 19);    // Set P1.19 high
        delay(100);
        LPC_GPIO1->FIOCLR |= (1 << 19);    // Clear P1.19 low
        delay(100);
		 LPC_GPIO1->FIOSET |= (1 << 20);    // Set P1.19 high
        delay(100);
        LPC_GPIO1->FIOCLR |= (1 << 20);    // Clear P1.19 low
        delay(100);
    }
}

void timer0_config(void) {
    LPC_SC->PCONP |= (1 << 1);    // Power up Timer0

    LPC_TIM0->PR = 14;            // Set the prescaler value
    LPC_TIM0->MR0 = 10000000;      // Set match register for 10 seconds delay
    LPC_TIM0->MCR = (1 << 0) | (1 << 1);  // Interrupt and Reset on Match0
    LPC_TIM0->TCR = 1 << 1;        // Reset Timer0
    LPC_TIM0->TCR = 1;              // Enable Timer0
	uart_str("Timer 0 Config Done\r\n");
}


void timer1_config(void) {
    LPC_SC->PCONP |= (1 << 1);    // Power up Timer1

    LPC_TIM1->PR = 14;            // Set the prescaler value
    LPC_TIM1->MR1 = 10000000;      // Set match register for 10 seconds delay
    LPC_TIM1->MCR = (1 << 0) | (1 << 1);  // Interrupt and Reset on Match0
    LPC_TIM1->TCR = 1 << 1;        // Reset Timer0
    LPC_TIM1->TCR = 1;              // Enable Timer0
	uart_str("Timer 1 Config Done\r\n");
}


void int_config(void) {
    NVIC_ClearPendingIRQ(TIMER0_IRQn);     // Clear pending interrupts for Timer0
    NVIC_SetPriority(TIMER0_IRQn, 1);      // Set priority for Timer0 interrupt
    NVIC_EnableIRQ(TIMER0_IRQn);           // Enable Timer0 interrupt 
	uart_str("Interrupt 0 Config Done\r\n");
	
	NVIC_ClearPendingIRQ(TIMER1_IRQn);     // Clear pending interrupts for Timer0
    NVIC_SetPriority(TIMER1_IRQn, 2);      // Set priority for Timer1 interrupt
    NVIC_EnableIRQ(TIMER1_IRQn);           // Enable Timer1 interrupt 
	uart_str("Interrupt 1 Config Done\r\n");   
}

void TIMER0_IRQHandler (void) {			  //ISR for timer 0
    uart_str("Int from Timer 0\r\n");       // Send a message through UART
    delay(100);

    LPC_TIM0->IR = 1 << 0;                 // Clear interrupt flag						  
    NVIC_ClearPendingIRQ(TIMER0_IRQn);     // Clear pending interrupt for Timer0
}


void TIMER1_IRQHandler (void) {			  //ISR for timer 1
    uart_str("Int from Timer 1\r\n");       // Send a message through UART
    delay(100);

    LPC_TIM0->IR = 1 << 0;                 // Clear interrupt flag
    NVIC_ClearPendingIRQ(TIMER1_IRQn);     // Clear pending interrupt for Timer0
}

  

