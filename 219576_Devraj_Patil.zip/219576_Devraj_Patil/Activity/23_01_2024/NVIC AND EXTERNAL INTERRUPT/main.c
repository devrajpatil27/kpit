


#include "LPC17xx.h"
#include <stdint.h>
#include "uart.h"

void exint_config(void);
void timer_config(void);

int main() {
    LPC_GPIO1->FIODIR |= (1 << 19);    // Configure P1.19 as output
	 LPC_GPIO1->FIODIR |= (1 << 24);   // Configure P1.24 as output
    uart_config();                     // Initialize UART configuration
    exint_config();
	timer_config();                      // Initialize interrupt configuration

    while (1) {
        LPC_GPIO1->FIOSET |= (1 << 19);    // Set P1.19 high
        delay(100);
        LPC_GPIO1->FIOCLR |= (1 << 19);    // Clear P1.19 low
        delay(100);
    }
}

void exint_config()
{
    NVIC_ClearPendingIRQ(EINT1_IRQn);
    NVIC_SetPriority(EINT1_IRQn, 1);      // Set priority for EINT1 interrupt
    NVIC_EnableIRQ(EINT1_IRQn);

    LPC_SC->EXTINT |= (1 << 1);           // Clear pending EINT1 interrupt
    LPC_SC->EXTMODE |= (1 << 1);          // Set EINT1 as edge-sensitive
    LPC_SC->EXTPOLAR &= ~(1 << 1);        // Set EINT1 to be sensitive to the falling edge
    LPC_PINCON->PINSEL4 &= ~(3 << 22);    // Clear bits 22 and 23
    LPC_PINCON->PINSEL4 |= (1 << 22);     // Set bits 22 for P2.11 as EINT1
    uart_str("EXT interrupt config done\r\n");

}
void timer_config(void) {
    NVIC_ClearPendingIRQ(TIMER0_IRQn);     // Clear pending interrupts for Timer0
    NVIC_SetPriority(TIMER0_IRQn, 1);      // Set priority for Timer0 interrupt
    NVIC_EnableIRQ(TIMER0_IRQn);         
	
	  
    LPC_SC->PCONP |= (1 << 1);    // Power up Timer0
    LPC_TIM0->PR = 14;            // Set the prescaler value
    LPC_TIM0->MR0 = 10000000;      // Set match register for 10 seconds delay
    LPC_TIM0->MCR = (1 << 0) | (1 << 1);  // Interrupt and Reset on Match0
    LPC_TIM0->TCR = 1 << 1;        // Reset Timer0
    LPC_TIM0->TCR = 1;              // Enable Timer0
	uart_str("internal Timer Config Done\r\n");
}

void EINT1_IRQHandler(void)
{	 uint32_t i;
    uart_str("EXT interrupt occurred\r\n");  // Print message when EINT1 interrupt occurs
    delay(100);
	for(i=0;i<10;i++)
	{
	    LPC_GPIO1->FIOSET |= (1 << 22);    // Set P1.22 high
        delay(100);
        LPC_GPIO1->FIOCLR |= (1 << 22);    // Clear P1.22 low
        delay(100);
	}
    LPC_SC->EXTINT |= (1 << 1);           // Clear pending EINT1 interrupt
    NVIC_ClearPendingIRQ(EINT1_IRQn);     // Clear pending interrupt flag for EINT1
}
void TIMER0_IRQHandler (void) {

    uint32_t i;
    uart_str("Int from Timer\r\n");       // Send a message through UART
    delay(1000);

		for(i=0;i<10;i++)
	{
	    LPC_GPIO1->FIOSET |= (1 << 24);    // Set P1.24 high
        delay(100);

        LPC_GPIO1->FIOCLR |= (1 << 24);    // Clear P1.24 low
        delay(100);
	}
    LPC_TIM0->IR = 1 << 0;                 // Clear interrupt flag
    NVIC_ClearPendingIRQ(TIMER0_IRQn);     // Clear pending interrupt for Timer0
}



  

