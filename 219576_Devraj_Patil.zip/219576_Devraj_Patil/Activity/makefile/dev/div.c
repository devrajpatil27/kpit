
#include "myheader.h"

int div(int n1, int n2)
{
    return n1 / n2;
}