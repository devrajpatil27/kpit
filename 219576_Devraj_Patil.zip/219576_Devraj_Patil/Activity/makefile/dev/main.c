#include <stdio.h>
#include "myheader.h"
int main()
{
    int n1, n2;
    char choice;

    printf("Enter two numbers\n");
    scanf("%d\n%d", &n1, &n2);
    printf("Enter operation +,-,*,/\n");
    scanf("%s", &choice);
    int res;
    
    switch (choice)
    {
    case '+':
        res = add(n1, n2);
        break;
    case '-':
        res = sub(n1, n2);
        break;
    case '*':
        res = mul(n1, n2);
        break;
    case '/':
        res = div(n1, n2);
        break;
    default:
        printf("enter correct choice\n");
    }
    printf("result is %d", res);
}