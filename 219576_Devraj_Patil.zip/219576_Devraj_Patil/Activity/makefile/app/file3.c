#include<stdio.h>
#include "functions.h"

void print_hello(){
    printf("Hello World!\n");
}