#ifndef _FUNC_H_
#define _FUNC_H_

void print_hello();
int factorial(int n);

#endif