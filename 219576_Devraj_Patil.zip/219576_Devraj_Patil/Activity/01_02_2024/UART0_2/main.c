#include <LPC17xx.h>
#include"lcd.h"
#include "uart0.h"
#include "uart2.h"

int main()
{

int val =20;
int val1;

uart0_config();
uart2_config();

while(1)
{
uart0_num(val);
delay(100);
val1 = uart2_rx();
lcd_data_write(val1);
delay(500);
lcd_cmd_write(0x01);

}

}
