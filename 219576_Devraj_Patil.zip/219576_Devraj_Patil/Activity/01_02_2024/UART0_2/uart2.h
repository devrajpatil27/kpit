#ifndef UART_H
#define UART_H

#include <lpc17xx.h>

//#define UART2_PCONP_ENABLE   (0x00000008)
//#define UART2_LCR_SETUP      (0x00000083)
//#define UART2_LCR_WORD_LEN8  (0x00000003)
//#define UART2_FCR_ENABLE     (0x07)

void uart2_config(void);
void uart2_data(unsigned char d);
void uart2_str(unsigned char *ptr);
void uart2_num(unsigned int num);
unsigned char uart2_rx(void);
void delay(unsigned int a);

void uart2_config()
{
    LPC_SC->PCONP |= (1<<24);   // UART0 peripheral enable
    LPC_PINCON->PINSEL0 |= (1<<20);
LPC_PINCON->PINSEL0 &= ~(1<<21);
LPC_PINCON->PINSEL0 &= ~(1<<23);

    LPC_UART2->LCR = 0x00000083;     // Enable divisor latch, parity disable, 1 stop bit, 8-bit word length
    LPC_UART2->DLM = 0X00;
    LPC_UART2->DLL = 0x1A;               // Select baud rate 9600 bps for 4Mhz
    LPC_UART2->LCR = 0x00000003; // Disable divisor latch
    LPC_UART2->FCR = 0X07;    // FIFO enable, RX FIFO reset, TX FIFO reset
}

void uart2_data(unsigned char d)
{
    while (!(LPC_UART2->LSR & (1 << 5))); // Check THR is empty or not, use polling method
    LPC_UART2->THR = d;                    // Load the data to THR
    delay(10);
}

void uart2_str(unsigned char *ptr)
{
    while (*ptr != '\0')
    {
        uart2_data(*ptr);
        ptr++;
    }
}

unsigned char uart2_rx()

{
    while (!(LPC_UART2->LSR & (1 << 0))); // Check RBR is received data or not
    return LPC_UART2->RBR;
}

void uart2_num(unsigned int num)
{
    if (num)
    {
        uart2_num(num / 10);
        uart2_data(num % 10 + 0x30);
    }
}

//void delay(unsigned int a)
//{
//    unsigned int i, j; // 100x 6000/60Mhz = 0.01s--
//    for (i = 0; i < a; i++)
//        for (j = 0; j < 6000; j++);
//}

  // UART_H

#endif

 