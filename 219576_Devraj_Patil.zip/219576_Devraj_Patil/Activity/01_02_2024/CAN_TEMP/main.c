#include <LPC17xx.h>
#include <stdio.h>
#include <stdint.h>
#include "lcd.h"
#include"lcd.c"
#define SWITCH_PIN1(X) (1 << X)
#define SWITCH_PIN2(Y) (1 << Y)
//#include "uart.h"
#define VREF       3.3 //Reference Voltage at VREFP pin, given VREFN = 0V(GND)
#define ADC_CLK_EN (1<<12)
#define SEL_AD0_2  (1<<2) //Select Channel AD0.1 
#define CLKDIV     (3 << 8)      //ADC clock-divider (ADC_CLOCK=PCLK/CLKDIV+1) = 1Mhz @ 4Mhz PCLK
#define PWRUP      (1<<21) //setting it to 0 will power it down
#define START_CNV  (1<<24) //001 for starting the conversion immediately
#define ADC_DONE   (1U<<31) //define it as unsigned value or compiler will throw #61-D warning int m
#define  T_COEFF 100.0f

#define CAN2_BAUD_RATE 100000  // Set the desired baud rate for CAN communication as 100Kbps
							   // So nominal bit time = 10 us

#define CAN1_BAUD_RATE 100000  // Set the desired baud rate for CAN communication as 100Kbps
							   // So nominal bit time = 10 us

void CAN2_Init(void);
void CAN1_Init(void);

void CAN2_MessageSend(uint32_t msgId, uint64_t data, uint8_t length);				 //transmitter function	, can2 is transmitter
void CAN1_MessageReceive(uint32_t *msgId, uint64_t *data, uint8_t *length);			 //reviecer function	,can1 is reciever

int main(void)
{	
    int result = 0;
	float volts = 0;
	float temp = 0;
    // Define test data for CAN message					  //data to be transmitted
    uint32_t tmsgId = 0x123;							 //identifer but of 12bits, max value of identifier can be 11
    uint64_t tmessageData;					 //24bits data
    uint8_t  tlength = 3; 								 //3 byte data
    
    // Variables for received CAN message		         //variable to store the recieved data
    uint32_t rmsgId;
    uint64_t rmessageData;
    uint8_t  rlength;  
    
    // Array for formatting CAN message data for LCD display
    char id_data[20];									    //char arr for displaying in LCD

    // Initialize LCD
    lcd_init();
    // Initialize UART (commented out)

    // Initialize CAN controllers
    CAN2_Init();    // Initialize CAN controller
    CAN1_Init();    // Initialize CAN controller
    // uart_str_transmit("ECU2 msg Txted");

	LPC_PINCON->PINSEL1 |= (0x01<<18) ; //select AD0.2 for P0.25
	LPC_SC->PCONP |= ADC_CLK_EN; //Enable ADC clock
	LPC_ADC->ADCR =  PWRUP | CLKDIV | SEL_AD0_2;

    LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN1(11));
	LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN2(11));       
    while (1) 
    {	   	
	        LPC_ADC->ADCR |= START_CNV; //Start new Conversion

		while((LPC_ADC->ADDR2 & ADC_DONE) == 0){} //Wait untill conversion is finished
		
		result = (LPC_ADC->ADDR2>>4) & 0xFFF; //12 bit Mask to extract result
		
		volts = (result*VREF)/4096.0; //Convert result to Voltage

		temp = volts * T_COEFF;

		tmessageData = temp;
		 CAN2_MessageSend(tmsgId, tmessageData, tlength);

         CAN1_MessageReceive(&rmsgId, &rmessageData, &rlength);
        
        // Display received CAN message on LCD
        sprintf(id_data,"Temp= %d",rmessageData);
        lcd_str_write(id_data);
		lcd_cmd_write(0xC0);
        // uart_str_transmit(id_data);
			if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN2(12)))!= 0 )
              {
            tmessageData=0x01;
			CAN2_MessageSend(tmsgId, tmessageData, tlength);
			sprintf(id_data,"%x",tmessageData);
            lcd_str_write(id_data);
            lcd_str_write(" sw1 Tx");
			delay(100);
			lcd_cmd_write(0x01);
			lcd_cmd_write(0xC0);

           CAN1_MessageReceive(&rmsgId, &rmessageData, &rlength);
        
           sprintf(id_data,"%x",rmessageData);
           lcd_str_write(id_data);
           lcd_str_write(" sw1 Rx");
           delay(100);
           lcd_cmd_write(0x01);
              }

		   if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN1(11)))!= 0 )
              {
            tmessageData=0x02;
			CAN2_MessageSend(tmsgId, tmessageData, tlength);
			sprintf(id_data,"%x",tmessageData);
            lcd_str_write(id_data);
            lcd_str_write(" sw2 Tx");
			delay(100);
			lcd_cmd_write(0x01);
			lcd_cmd_write(0xC0);
           CAN1_MessageReceive(&rmsgId, &rmessageData, &rlength);
        
           sprintf(id_data,"%x",rmessageData);
           lcd_str_write(id_data);
           lcd_str_write(" sw2 Rx");
           delay(100);
           lcd_cmd_write(0x01);
              }


    }
}

// Function to initialize CAN2 controller- sender
void CAN2_Init(void) 										   //can2 must be configured as transmitter
{
    // Set P2.7 as RD2 and P2.8 as TD2 CAN2 PINS
    LPC_PINCON->PINSEL4 |=  (1 << 14);//receiver 15,14 - 01
    LPC_PINCON->PINSEL4 &= ~(1 << 15);
    LPC_PINCON->PINSEL4 |=  (1 << 16);//transmitter 17,16 - 01
    LPC_PINCON->PINSEL4 &= ~(1 << 17);
    
    // Enable power to CAN2 controller
    LPC_SC->PCONP |= (1 << 14);
    
    // Set CAN2 in Reset mode
    LPC_CAN2->MOD = 1;
    
    // Configure the Baud Rate for CAN2
    LPC_CAN2->BTR = (1<<23)|(1<<20)|(6<<16)|(0X00); // CAN2 clock = PCLK/(0+1)= 1MHz/1=1000KHz  i.e Time Quanta = 1 us
                                                    // i.e total time quanta = 10us/1us = 10
                                                    // (1+TSEG1)/(1+TSEG1+TSEG2)= 80% => (1+TSEG1)/10 = 80% => TSEG1 = 7 and TSEG2 = 2
    
    // Set CAN2 in Normal mode
    LPC_CAN2->MOD = 0;
}

// Function to send a CAN message using CAN2 controller
void CAN2_MessageSend(uint32_t msgId, uint64_t data, uint8_t length) 
{
    // Wait until Transmit Buffer 1 (TBR1) is empty
    while((LPC_CAN2->GSR & (1 << 2)) == 0){ }	//we are checking if transmitter buffer register is empty to hold the data
    
    // Set the message ID
    LPC_CAN2->TID1 = msgId;
    
    // If extended message ID, set the Extended Identifier Flag
    if(msgId > 0x7FF)								  //07ff is the max number we can write using 11 bits.
    {
        LPC_CAN2->TFI1 |= (1U << 31);				   //create extended frame is id is greater than 11 bits , creating a 29 bits frame	for accomodate 12 bits
    }

    // Set data length code
    LPC_CAN2->TFI1 |= ((uint32_t)length << 16);			//craeting extra space pf 3 bits to accomodate extra bits above 11bits

    // If data length is greater than 4 bytes, set the first 4 bytes of data
    if(length > 4)						    //register capacity is 4 bytes, if data is greater than 4 than use another register TDB1
    {
        LPC_CAN2->TDB1 = data >> 32;		//extra bits will go in TDB1, remaining previous 4 bytes of data will be accomodated in TDA1.
    }
    
    // Set the next 4 bytes of data
    LPC_CAN2->TDA1 = (uint32_t)data;		//extra bits will go in TDB1, remaining previous 4 bytes of data will be accomodated in TDA1.
    
    // Enable queued transmission and select Tx Buffer1
    LPC_CAN2->CMR |= (1 << 0)|(1 << 5);		//both tda and tdb will give data to transmitter buffer
    													  
    // Wait for transmission completion
    while ((LPC_CAN2->GSR & (1 << 3)) == 0) { }	//we are checking if transmittion is successful. 
}

// Function to initialize CAN1 controller
void CAN1_Init(void) 
{
    // Set P0.0 as RD1 and P0.1 as TD1
    LPC_PINCON->PINSEL0 |= (1 << 0);
    LPC_PINCON->PINSEL0 &= ~(1 << 1);
    LPC_PINCON->PINSEL0 |= (1 << 2);
    LPC_PINCON->PINSEL0 &= ~(1 << 3);
    
    // Enable power to CAN1 controller
    LPC_SC->PCONP |= (1 << 13);
    
    // Set CAN1 in Reset mode
    LPC_CAN1->MOD = 1;
    
    // Configure the Baud Rate for CAN1
    LPC_CAN1->BTR = (1<<23)|(1<<20)|(6<<16)|(0X00); // CAN1 clock = PCLK/(0+1)= 1MHz/1=1000KHz  i.e Time Quanta = 1 us
                                                    // i.e total time quanta = 10us/1us = 10
                                                    // (1+TSEG1)/(1+TSEG1+TSEG2)= 80% => (1+TSEG1)/10 = 80% => TSEG1 = 7 and TSEG2 = 2
    
    // Set CAN1 in Normal mode
    LPC_CAN1->MOD = 0;
}

// Function to receive a CAN message using CAN1 controller
void CAN1_MessageReceive(uint32_t *msgId, uint64_t *data, uint8_t *length) 
{
    // Wait until Receive Buffer (RBR) is not empty
    while((LPC_CAN1->GSR & (1<<0))==1){ }  //we are checking if reciever buffer register is empty to hold the data.
    
    // Load the message ID to a variable
    *msgId = LPC_CAN1->RID;

    // Extract data length code from the frame status
    *length = (LPC_CAN1->RFS >> 16) & 0x0F ;
    
    // Load the first 4 bytes of received data
    *data = LPC_CAN1->RDA;
    
    // If data length is greater than 4 bytes, load the next 4 bytes of data
    if(*length > 4)
    {
        *data = *data | ((uint64_t)LPC_CAN1->RDB << 32);
    }

    // Release the buffer
    LPC_CAN1->CMR=(1<<2);
}

































//#include <LPC17xx.h>
//#include <stdio.h>
//#include <stdint.h>
//#include "lcd.h"
////#include "uart.h"
//#define LCD_H
//#define LCD_DATA_PINS (0xFF << 15)
//#define LCD_RS_PIN(X) (1 << X)
//#define LCD_EN_PIN(X) (1 << X)
//#define SWITCH_PIN(X) (1 << X)
//
//#define CAN2_BAUD_RATE 100000  // Set the desired baud rate for CAN communication as 100Kbps
//                 // So nominal bit time = 10 us
//
//#define CAN1_BAUD_RATE 100000  // Set the desired baud rate for CAN communication as 100Kbps
//                 // So nominal bit time = 10 us
//#define VREF       3.3 //Reference Voltage at VREFP pin, given VREFN = 0V(GND)
//#define ADC_CLK_EN (1<<12)
//#define SEL_AD0_2  (1<<2) //Select Channel AD0.1 
//#define CLKDIV     (3 << 8)      //ADC clock-divider (ADC_CLOCK=PCLK/CLKDIV+1) = 1Mhz @ 4Mhz PCLK
//#define PWRUP      (1<<21) //setting it to 0 will power it down
//#define START_CNV  (1<<24) //001 for starting the conversion immediately
//#define ADC_DONE   (1U<<31) //define it as unsigned value or compiler will throw #61-D warning int m
//
//#define  T_COEFF 100.0f	
//
//void CAN2_Init(void);
//void CAN1_Init(void);
//void delay(uint32_t );
//void CAN2_MessageSend(uint32_t msgId, uint64_t data, uint8_t length);
//void CAN1_MessageReceive(uint32_t *msgId, uint64_t *data, uint8_t *length);
//
//void lcd_cmd_write(char cmd)
//{
//	LPC_GPIO0 -> FIOCLR = LCD_DATA_PINS;
//	LPC_GPIO0 -> FIOSET = cmd << 15;
//	LPC_GPIO0 -> FIOCLR = LCD_RS_PIN(10);
//	LPC_GPIO0 -> FIOSET = LCD_EN_PIN(11);
//	delay(10);
//	LPC_GPIO0 -> FIOCLR = LCD_EN_PIN(11);
//	return;
//}
//void lcd_data_write(char dat)
//{
//	LPC_GPIO0 -> FIOCLR = LCD_DATA_PINS;
//	LPC_GPIO0 -> FIOSET = dat << 15;
//	LPC_GPIO0 -> FIOSET = LCD_RS_PIN(10);
//	LPC_GPIO0 -> FIOSET = LCD_EN_PIN(11);
//	delay(10);
//	LPC_GPIO0 -> FIOCLR = LCD_EN_PIN(11);
//	return;
//}
//void lcd_str_write(char *str)
//{
//	while(*str != '\0')
//	{
//		lcd_data_write(*str);
//		str++;
//	}
//	return;
//}
//void lcd_init(void)
//{
//	LPC_GPIO0 -> FIODIR |= LCD_DATA_PINS;
//	LPC_GPIO0 -> FIODIR |= LCD_RS_PIN(10);
//	LPC_GPIO0 -> FIODIR |= LCD_EN_PIN(11);
//	lcd_cmd_write(0x38);
//	lcd_cmd_write(0x0E);
//	lcd_cmd_write(0x01);
//	return;
//}
//void delay(uint32_t ms)
//{
//	uint32_t i,j,k;
//	for(i = 0 ; i < ms ; i++)
//	{
//		k = 0 ;
//		for(j = 0 ; j < 3000 ; j++)
//		{
//			k++ ;
//		}
//	}
//	return ;
//} 
//int main(void)
//{
//	int result = 0;
//	float volts = 0;
//	float temp = 0;	 
//    // Define test data for CAN message
//    uint32_t tmsgId = 0x123;
//    uint64_t tmessageData;
//    uint8_t  tlength = 3; 
//    
//    // Variables for received CAN message
//    uint32_t rmsgId;
//    uint64_t rmessageData;
//    uint8_t  rlength;  
//    
//    // Array for formatting CAN message data for LCD display
//    char id_data[20];
//	LPC_PINCON->PINSEL1 |= (0x01<<18) ; //select AD0.2 for P0.25
//	LPC_SC->PCONP |= ADC_CLK_EN; //Enable ADC clock
//	LPC_ADC->ADCR =  PWRUP | CLKDIV | SEL_AD0_2;
//	LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN(12));
//	LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN(11));
//    // Initialize LCD
//    lcd_init();
//    // Initialize UART (commented out)
//
//    // Initialize CAN controllers
//    CAN2_Init();    // Initialize CAN controller
//    CAN1_Init();    // Initialize CAN controller
//    // uart_str_transmit("ECU2 msg Txted");
//	lcd_cmd_write(0x0C);
//           
//    while (1) 
//    {
//		LPC_ADC->ADCR |= START_CNV; //Start new Conversion
//
//		while((LPC_ADC->ADDR2 & ADC_DONE) == 0){} //Wait untill conversion is finished
//		
//  		result = (LPC_ADC->ADDR2>>4) & 0xFFF; //12 bit Mask to extract result
//		
//		volts = (result*VREF)/4096.0; //Convert result to Voltage
//		temp = volts * T_COEFF;	
//		tmessageData=temp;
//		CAN2_MessageSend(tmsgId, tmessageData, tlength);
//		delay(1000);
//        CAN1_MessageReceive(&rmsgId, &rmessageData, &rlength); 
//        // Display received CAN message on LCD
//        sprintf(id_data,"Temperature %llx",rmessageData);
//        lcd_str_write(id_data);
//        // Wait for a moment
//        lcd_cmd_write(0xC0);
//
//        // Display transmitted CAN message on LCD
//        /*sprintf(id_data,"%x %llx",tmsgId,tmessageData);
//        lcd_str_write(id_data);
//        lcd_cmd_write(0xC0);
//        lcd_str_write("ECU2 msg Txted");	*/
//        // uart_str_transmit(id_data);
//        
//        // Wait for a moment
//		if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN(12)))!=0)
//		{
//			  tmessageData=1;
//		}
//		else if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN(11)))!=0)
//		{
//			  tmessageData=0;
//		}
//        // Transmit CAN message
//        CAN2_MessageSend(tmsgId, tmessageData, tlength);
//        // Receive CAN message
//        CAN1_MessageReceive(&rmsgId, &rmessageData, &rlength);
//        
//        // Display received CAN message on LCD
//        /*sprintf(id_data,"%x %llx",rmsgId,rmessageData);
//        lcd_str_write(id_data);
//        lcd_cmd_write(0xC0);*/
//		if(rmessageData==1)
//        	lcd_str_write("Switch2 Pressed");
//        // uart_str_transmit(id_data);
//        else if(rmessageData==0)
//			lcd_str_write("Switch1 Pressed");
//		else
//			lcd_str_write("NO press");
//        // Wait for a moment
//        delay(1000);
//        lcd_cmd_write(0x01);
//    }
//}
//
//// Function to initialize CAN2 controller
//void CAN2_Init(void) 
//{
//    // Set P2.7 as RD2 and P2.8 as TD2 CAN2 PINS
//    LPC_PINCON->PINSEL4 |=  (1 << 14);
//    LPC_PINCON->PINSEL4 &= ~(1 << 15);
//    LPC_PINCON->PINSEL4 |=  (1 << 16);
//    LPC_PINCON->PINSEL4 &= ~(1 << 17);
//    
//    // Enable power to CAN2 controller
//    LPC_SC->PCONP |= (1 << 14);
//    
//    // Set CAN2 in Reset mode
//    LPC_CAN2->MOD = 1;
//    
//    // Configure the Baud Rate for CAN2
//    LPC_CAN2->BTR = (1<<23)|(1<<20)|(6<<16)|(0X00); // CAN2 clock = PCLK/(0+1)= 1MHz/1=1000KHz  i.e Time Quanta = 1 us
//                                                    // i.e total time quanta = 10us/1us = 10
//                                                    // (1+TSEG1)/(1+TSEG1+TSEG2)= 80% => (1+TSEG1)/10 = 80% => TSEG1 = 7 and TSEG2 = 2
//    
//    // Set CAN2 in Normal mode
//    LPC_CAN2->MOD = 0;
//}
//
//// Function to send a CAN message using CAN2 controller
//void CAN2_MessageSend(uint32_t msgId, uint64_t data, uint8_t length) 
//{
//    // Wait until Transmit Buffer 1 (TBR1) is empty
//    while((LPC_CAN2->GSR & (1 << 2)) == 0){ }
//    
//    // Set the message ID
//    LPC_CAN2->TID1 = msgId;
//    
//    // If extended message ID, set the Extended Identifier Flag
//    if(msgId > 0x7FF)
//    {
//        LPC_CAN2->TFI1 |= (1U << 31);
//    }
//
//    // Set data length code
//    LPC_CAN2->TFI1 |= ((uint32_t)length << 16);
//
//    // If data length is greater than 4 bytes, set the first 4 bytes of data
//    if(length > 4)
//    {
//        LPC_CAN2->TDB1 = data >> 32;
//    }    
//    // Set the next 4 bytes of data
//    LPC_CAN2->TDA1 = (uint32_t)data;
//    // Enable queued transmission and select Tx Buffer1
//    LPC_CAN2->CMR |= (1 << 0)|(1 << 5);
//    
//    // Wait for transmission completion
//    while ((LPC_CAN2->GSR & (1 << 3)) == 0) { }
//}
//// Function to initialize CAN1 controller
//void CAN1_Init(void) 
//{
//    // Set P0.0 as RD1 and P0.1 as TD1
//    LPC_PINCON->PINSEL0 |= (1 << 0);
//    LPC_PINCON->PINSEL0 &= ~(1 << 1);
//    LPC_PINCON->PINSEL0 |= (1 << 2);
//    LPC_PINCON->PINSEL0 &= ~(1 << 3);
//    
//    // Enable power to CAN1 controller
//    LPC_SC->PCONP |= (1 << 13);
//    
//    // Set CAN1 in Reset mode
//    LPC_CAN1->MOD = 1;
//    
//    // Configure the Baud Rate for CAN1
//    LPC_CAN1->BTR = (1<<23)|(1<<20)|(6<<16)|(0X00); // CAN1 clock = PCLK/(0+1)= 1MHz/1=1000KHz  i.e Time Quanta = 1 us
//                                                    // i.e total time quanta = 10us/1us = 10
//                                                    // (1+TSEG1)/(1+TSEG1+TSEG2)= 80% => (1+TSEG1)/10 = 80% => TSEG1 = 7 and TSEG2 = 2
//    // Set CAN1 in Normal mode
//    LPC_CAN1->MOD = 0;
//}
//
//// Function to receive a CAN message using CAN1 controller
//void CAN1_MessageReceive(uint32_t *msgId, uint64_t *data, uint8_t *length) 
//{
//    // Wait until Receive Buffer (RBR) is not empty
//    while((LPC_CAN1->GSR & (1<<0))==1){ }
//    
//    // Load the message ID to a variable
//    *msgId = LPC_CAN1->RID;
//
//    // Extract data length code from the frame status
//    *length = (LPC_CAN1->RFS >> 16) & 0x0F ;
//    
//    // Load the first 4 bytes of received data
//    *data = LPC_CAN1->RDA;
//    
//    // If data length is greater than 4 bytes, load the next 4 bytes of data
//    if(*length > 4)
//    {
//        *data = *data | ((uint64_t)LPC_CAN1->RDB << 32);
//    }
//
//    // Release the buffer
//    LPC_CAN1->CMR=(1<<2);
//}