//WAP to control relay, Buzzer and leds using serial input through UART.
//1. Serial input '1' turn on buzzer '2' to turn off buzzer.
//2.Serial input '3' turn on relay '4' to turn off relay.
//3.Serial input '5' turn on Led '6' to turn off Led.
//4.Serial input '7' to blink odd leds.
//5.Serial input '8' to blink even leds. Using LPC1768 microcontroller in embedded c

//print back the status msg in uart terminal after every option run

#include <lpc17xx.h>
#include "uart.h"
//#include<lcd.h>
#define RELAY (1<<28)
#define BUZZER (1<<27)
#define LED3 (1 << 19)
#define LED1 (0xAA<<19)
#define LED2 (0x55 << 19)

int main(){

char val;

LPC_GPIO1->FIODIR|=RELAY;
LPC_GPIO1->FIODIR|=BUZZER;
LPC_GPIO1->FIODIR|=LED1;
LPC_GPIO1->FIODIR|=LED2;

uart_config();
  while(1)
  {
  uart_str("Enter a number:");
  val=uart_rx();
  delay(100);

  switch(val){
  case '1':
  LPC_GPIO1->FIOSET=BUZZER;
  break;
  case '2':
  LPC_GPIO1->FIOCLR=BUZZER;
  case '3':
  LPC_GPIO1->FIOSET=RELAY;
  break;
  case '4':
  LPC_GPIO1->FIOCLR=RELAY;
  break;
  case '5':
  LPC_GPIO1->FIOSET=LED3;
  break;
  case '6':
  LPC_GPIO1->FIOCLR=LED3;
  break;
  case '7':
  LPC_GPIO1->FIOSET=LED1;
  delay(100);
  LPC_GPIO1->FIOCLR=LED1;
  delay(100);
  break;
  case '8':
  LPC_GPIO1->FIOSET=LED2;
  delay(100);
  LPC_GPIO1->FIOCLR=LED2;
  delay(100);
  break;
  }
  uart_str("\r\n")	 ;
  }
  }






//  #include<lpc17xx.h>
//#include"uart.h"
//
//#define EVEN_LED_PINS (0x55 << 19)
//#define ODD_LED_PINS (0XAA << 19)
//
//int main()
//{
//	unsigned char c = '0';
//	LPC_GPIO0 -> FIODIR |= (1 << 27);	//Buzzer output.
//	LPC_GPIO1 -> FIODIR |= (1 << 28);	//Relay output.
//	LPC_GPIO1 -> FIODIR |= EVEN_LED_PINS;	//Even LED's
//	LPC_GPIO1 -> FIODIR |= ODD_LED_PINS;	//Odd LED's
//	uart_config();
//	while(1)
//	{
//		if(LPC_UART0->LSR & (1 << 0))
//			c = LPC_UART0->RBR;
//		
//		if(c == '1')
//			LPC_GPIO0 -> FIOSET |= (1 << 27);
//		if(c == '2')
//			LPC_GPIO0 -> FIOCLR |= (1 << 27);
//		if(c == '3')
//			LPC_GPIO1 -> FIOSET |= (1 << 28);
//		if(c == '4')
//			LPC_GPIO1 -> FIOCLR |= (1 << 28);
//		if(c == '5')
//			LPC_GPIO1 -> FIOSET |= (0xFF << 19);
//		if(c == '6')
//			LPC_GPIO1 -> FIOCLR |= (0xFF << 19);
//		if(c == '7')
//			LPC_GPIO1 -> FIOPIN ^= ODD_LED_PINS;
//		if(c == '8')
//			LPC_GPIO1 -> FIOPIN ^= EVEN_LED_PINS;	
//		delay(100); 
//	}
//}
