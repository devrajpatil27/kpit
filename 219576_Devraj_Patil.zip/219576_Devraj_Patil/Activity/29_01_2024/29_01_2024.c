
#include <stdio.h>

int main() {
    int a=5;
    int b=10;
    int sum=a+b;
    printf("sum= %d\n",sum);

  
  
}
