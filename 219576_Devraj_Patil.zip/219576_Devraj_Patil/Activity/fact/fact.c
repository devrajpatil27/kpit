#include <LPC17xx.h>
#include <stdint.h>
#include "uart.h"

void delay(uint32_t ); 

int main(void)
{
int num=5;
int i;
int product=1;
uart_config();
	for( i=1; i<=num; i++)
	{
		product*=i;
	}
	uart_str("Factorial= ");
	uart_num(product);
	uart_str("\n") ;

return 0;
}