#include <lpc17xx.h>
#include "uart.h"

void SystemInit(void);

int main() {
    int count = 0;
    
    LPC_PINCON->PINSEL3 &= ~(0xFF << 26); // Configure P1.29 to P1.22 as GPIO
    LPC_GPIO1->FIODIR |= 0xFF << 22; // Configure P1.29 to P1.22 as output
    
    uart_config();
    uart_str("CPU at default MHz\r\n");

    while (1) {
        LPC_GPIO1->FIOSET |= 0xFF << 22;
        delay(400);
        LPC_GPIO1->FIOCLR |= 0xFF << 22;
        delay(400);

        if (count == 10)
            SystemInit();
        else
            count++;
    }
}

void SystemInit(void) {
    // Initialize the PLL
    LPC_SC->SCS = 0x00000020; // Enable the main oscillator (bit 5)
    while (!(LPC_SC->SCS & 0x00000040)); // Wait for the main oscillator to be ready (bit 6)

    LPC_SC->CCLKCFG = 0x00000003; // Set the CPU clock divider to 3 (for a 72MHz CPU clock)
    
    LPC_SC->CLKSRCSEL = 0x00000001; // Select the main oscillator as the PLL clock source
    
    LPC_SC->PLL0CFG = 0x00050063; // M=5, P=2 (multiply by 5, divide by 2)
    LPC_SC->PLL0CON = 0x01;       // Enable the PLL
    LPC_SC->PLL0FEED = 0xAA;
    LPC_SC->PLL0FEED = 0x55;

    while (!(LPC_SC->PLL0STAT & (1 << 26))); // Wait for PLL lock (bit 26)

    LPC_SC->PLL0CON = 0x03; // Connect the PLL (bit 1)
    LPC_SC->PLL0FEED = 0xAA;
    LPC_SC->PLL0FEED = 0x55;

    while (!(LPC_SC->PLL0STAT & (1 << 25))); // Wait for PLLC to be set (bit 25)
    
    LPC_SC->PCLKSEL0 |= (1 << 2) | (1 << 3); // Set peripheral clock divider to 1 for PCLK_UART0 and PCLK_UART1
    
    LPC_SC->PCLKSEL1 &= ~(0x03 << 18); // Set peripheral clock divider to 1 for PCLK_UART2
    LPC_SC->PCLKSEL1 |= (0x01 << 18);
    uart_str("CPU at 100 MHz\r\n");
}

