//driver code for 16 X 2 LCD for 8-bit 2-line display mode operation
//LCD pin connections
// LCD          - LPC1768
//------------------------
// RS           -  P0.10
// EN           -  P0.11
// DATA [D7-D0] -  [P0.22 - P0.15] 

#include <LPC17xx.h>

#include <stdint.h>

#define LCD_DATA_PINS (0xFF << 15)
#define LCD_RS_PIN(X) (1 << X)
#define LCD_EN_PIN(X) (1 << X)

void lcd_init(void);
void lcd_cmd_write(char);
void lcd_data_write(char);
void lcd_str_write(char *);
void delay(uint32_t ); 

int main(void)
{

char letter = 'A';
char message[] = "KPIT Bangalore";

lcd_init();

lcd_data_write(letter);

delay(200);

lcd_cmd_write(0xC0);

lcd_str_write(message);

delay(1000);

lcd_cmd_write(0x01);

return 0;
}


void lcd_cmd_write(char cmd)
{
LPC_GPIO0 -> FIOCLR = LCD_DATA_PINS;
LPC_GPIO0 -> FIOSET = cmd << 15;
LPC_GPIO0 -> FIOCLR = LCD_RS_PIN(10);
LPC_GPIO0 -> FIOSET = LCD_EN_PIN(11);
delay(100);
LPC_GPIO0 -> FIOCLR = LCD_EN_PIN(11);
return;
}

void lcd_data_write(char dat)
{
LPC_GPIO0 -> FIOCLR = LCD_DATA_PINS;
LPC_GPIO0 -> FIOSET = dat << 15;
LPC_GPIO0 -> FIOSET = LCD_RS_PIN(10);
LPC_GPIO0 -> FIOSET = LCD_EN_PIN(11);
delay(100);
LPC_GPIO0 -> FIOCLR = LCD_EN_PIN(11);
return;
}

void lcd_str_write(char *str)
{
 while(*str != '\0')
 {
  lcd_data_write(*str);
  str++;
 }
return;
}

void lcd_init(void)
{
LPC_GPIO0 -> FIODIR |= LCD_DATA_PINS;
LPC_GPIO0 -> FIODIR |= LCD_RS_PIN(10);
LPC_GPIO0 -> FIODIR |= LCD_EN_PIN(11);
lcd_cmd_write(0x38);
lcd_cmd_write(0x0E);
lcd_cmd_write(0x01);
return;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
 k++ ;
}

}
 return ; 
}