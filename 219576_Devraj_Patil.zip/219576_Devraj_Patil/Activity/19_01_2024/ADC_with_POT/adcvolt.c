#include <stdio.h>
#include "lcd.h"
#define VREF       3.3 //Reference Voltage at VREFP pin, given VREFN = 0V(GND)
#define ADC_CLK_EN (1<<12)
#define SEL_AD0_2  (1<<2) //Select Channel AD0.1 
#define CLKDIV     (3 << 8)      //ADC clock-divider (ADC_CLOCK=PCLK/CLKDIV+1) = 1Mhz @ 4Mhz PCLK
#define PWRUP      (1<<21) //setting it to 0 will power it down
#define START_CNV  (1<<24) //001 for starting the conversion immediately
#define ADC_DONE   (1U<<31) //define it as unsigned value or compiler will throw #61-D warning int m

#define  T_COEFF 100.0f
int main(void)
{
	int result = 0;

	float volts = 0;
	char svolts[20];

	float temp = 0;
  	char stemp[20];
	
	LPC_PINCON->PINSEL1 |= (0x01<<18) ; //select AD0.2 for P0.25
	LPC_SC->PCONP |= ADC_CLK_EN; //Enable ADC clock
	LPC_ADC->ADCR =  PWRUP | CLKDIV | SEL_AD0_2;
	
	lcd_init();
		
	while(1)
	{
		LPC_ADC->ADCR |= START_CNV; //Start new Conversion

		while((LPC_ADC->ADDR2 & ADC_DONE) == 0){} //Wait untill conversion is finished
		
		result = (LPC_ADC->ADDR2>>4) & 0xFFF; //12 bit Mask to extract result
		
		volts = (result*VREF)/4096.0; //Convert result to Voltage
		sprintf(svolts,"voltage=%.2f V",volts);
		lcd_str_write(svolts);
		lcd_cmd_write(0xC0);
        
		temp = volts * T_COEFF;
		sprintf(stemp,"Temp=%.2f 'C",temp);
		lcd_str_write(stemp);
		delay(500); //Slowing down Updates to 2 Updates per second
	    lcd_cmd_write(0x01);
	}
	
	return 0; //This won't execute
}