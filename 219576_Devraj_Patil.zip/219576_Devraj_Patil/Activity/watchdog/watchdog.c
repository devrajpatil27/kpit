#include "LPC17xx.h"


void delay_ms(uint32_t ms) {
    uint32_t i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 10000; j++);
}

int main() {
    LPC_GPIO1->FIODIR |= (0xFF << 19);   // Make LEDs on P1.19 to P1.26 as output
    LPC_GPIO1->FIODIR |= (1 << 27);      // P1.27 is connected to the buzzer

    LPC_GPIO1->FIOSET |= (1 << 27);      // Turn on the buzzer
    delay_ms(1000);
    LPC_GPIO1->FIOCLR |= (1 << 27);      // Turn off the buzzer

    LPC_WDT->WDTC = 0x1FFFFFF;            // Set watchdog timer value
    LPC_WDT->WDMOD = (1 << 1) | (1 << 0); // Counter clear, enable watchdog
    LPC_WDT->WDFEED = 0xAA;
    LPC_WDT->WDFEED = 0x55;

    while (1) {
        LPC_GPIO1->FIOSET |= (0xFF << 19);  // Turn on LEDs on P1.19 to P1.26
        delay_ms(100);
        LPC_GPIO1->FIOCLR |= (0xFF << 19);  // Turn off LEDs on P1.19 to P1.26
        delay_ms(100);
    }
}

