//all led toggle
// led pins : P1.19 - P1.26

#include <LPC17xx.h>

#include <stdint.h>

#define ALL_LED_PINS (0x81<< 19)
#define ALL_LED_PINS1 (0x42<< 19)
#define ALL_LED_PINS2 (0x24<< 19)
#define ALL_LED_PINS3 (0x18<< 19)

void delay(uint32_t); 

int main(void)
{
LPC_GPIO1 -> FIODIR |= ALL_LED_PINS;

while(1)
{
LPC_GPIO1 -> FIOSET = ALL_LED_PINS;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS; 
delay(250);

LPC_GPIO1 -> FIOSET = ALL_LED_PINS1;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS1; 
delay(250);


LPC_GPIO1 -> FIOSET = ALL_LED_PINS2;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS2; 
delay(250);


LPC_GPIO1 -> FIOSET = ALL_LED_PINS3;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS3; 
delay(250);


//LPC_GPIO1 -> FIOSET = ALL_LED_PINS1;
//delay(500);
//LPC_GPIO1 -> FIOCLR = ALL_LED_PINS1; 
//delay(500);
}


return 0;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
 k++ ;
}

}
 return ; 
}
//all led toggle
// led pins : P1.19 - P1.26

#include <LPC17xx.h>

#include <stdint.h>

#define ALL_LED_PINS (0x81<< 19)
#define ALL_LED_PINS1 (0x42<< 19)
#define ALL_LED_PINS2 (0x24<< 19)
#define ALL_LED_PINS3 (0x18<< 19)

void delay(uint32_t); 

int main(void)
{
LPC_GPIO1 -> FIODIR |= ALL_LED_PINS;

while(1)
{
LPC_GPIO1 -> FIOSET = ALL_LED_PINS;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS; 
delay(250);

LPC_GPIO1 -> FIOSET = ALL_LED_PINS1;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS1; 
delay(250);


LPC_GPIO1 -> FIOSET = ALL_LED_PINS2;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS2; 
delay(250);


LPC_GPIO1 -> FIOSET = ALL_LED_PINS3;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS3; 
delay(250);


//LPC_GPIO1 -> FIOSET = ALL_LED_PINS1;
//delay(500);
//LPC_GPIO1 -> FIOCLR = ALL_LED_PINS1; 
//delay(500);
}


return 0;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
 k++ ;
}

}
 return ; 
}




















//all led toggle
// led pins : P1.19 - P1.26

#include <LPC17xx.h>

#include <stdint.h>

#define ALL_LED_PINS (0x81<< 19)
#define ALL_LED_PINS1 (0x42<< 19)
#define ALL_LED_PINS2 (0x24<< 19)
#define ALL_LED_PINS3 (0x18<< 19)

void delay(uint32_t); 

int main(void)
{
LPC_GPIO1 -> FIODIR |= ALL_LED_PINS;

while(1)
{
LPC_GPIO1 -> FIOSET = ALL_LED_PINS;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS; 
delay(250);

LPC_GPIO1 -> FIOSET = ALL_LED_PINS1;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS1; 
delay(250);


LPC_GPIO1 -> FIOSET = ALL_LED_PINS2;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS2; 
delay(250);


LPC_GPIO1 -> FIOSET = ALL_LED_PINS3;
delay(250);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS3; 
delay(250);


//LPC_GPIO1 -> FIOSET = ALL_LED_PINS1;
//delay(500);
//LPC_GPIO1 -> FIOCLR = ALL_LED_PINS1; 
//delay(500);
}


return 0;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
 k++ ;
}

}
 return ; 
}







/*
#include <LPC17xx.h>
#include <stdint.h>
#define LED_PINS (0xC3 << 19)

void delay(uint32_t); 

int main(void)
{
	LPC_GPIO1 -> FIODIR |= LED_PINS;

	while(1)
	{
		LPC_GPIO1 -> FIOSET = LED_PINS;
		delay(500);
		LPC_GPIO1 -> FIOCLR = LED_PINS; 
		delay(500);
	}
	
	return 0;
}
	
void delay(uint32_t ms)
{
	uint32_t i,j,k;
	for(i = 0 ; i < ms ; i++)
	{
		k = 0 ;
		for(j = 0 ; j < 3000 ; j++)
		{
			 k++ ;
		}
	}
	return ; 
}
/*
#include <LPC17xx.h>
#include <stdint.h>
#define EVEN_LED_PINS (0x55 << 19)
#define ODD_LED_PINS (0XAA << 19)

void delay(uint32_t); 

int main(void)
{
	LPC_GPIO1 -> FIODIR |= EVEN_LED_PINS;
	LPC_GPIO1 -> FIODIR |= ODD_LED_PINS;
	while(1)
	{
		LPC_GPIO1 -> FIOSET = EVEN_LED_PINS;
		LPC_GPIO1 -> FIOCLR = ODD_LED_PINS;
		delay(500);
		LPC_GPIO1 -> FIOSET = ODD_LED_PINS;
		LPC_GPIO1 -> FIOCLR = EVEN_LED_PINS; 
		delay(500);
	}
	
	return 0;
}
	
void delay(uint32_t ms)
{
	uint32_t i,j,k;
	for(i = 0 ; i < ms ; i++)
	{
		k = 0 ;
		for(j = 0 ; j < 3000 ; j++)
		{
			 k++ ;
		}
	}
	return ; 
}



 */

/*

#include <LPC17xx.h>

#include <stdint.h>

#define ALL_LED_PINS (0xAA << 19)

void delay(uint32_t); 

int main(void)
{
LPC_GPIO1 -> FIODIR |= (0xAA << 19);

while(1)
{
LPC_GPIO1 -> FIOSET = ALL_LED_PINS;
delay(500);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS; 
delay(500);
}

return 0;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
	 k++ ;
}

}
 return ; 
}
*/

/*
// led pins : P1.19 - P1.26

#include <LPC17xx.h>

#include <stdint.h>

#define ALL_LED_PINS (0x01 << 26)

void delay(uint32_t); 

int main(void)
{
LPC_GPIO1 -> FIODIR |= (0x01 << 26);

while(1)
{
LPC_GPIO1 -> FIOSET = ALL_LED_PINS;
delay(500);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS; 
delay(500);
}

return 0;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
	 k++ ;
}

}
 return ; 
}

	 */


//all led toggle
// led pins : P1.19 - P1.26

/*#include <LPC17xx.h>

#include <stdint.h>

#define ALL_LED_PINS (0xFF << 19)

void delay(uint32_t); 

int main(void)
{
LPC_GPIO1 -> FIODIR |= (0xFF << 19);

while(1)
{
LPC_GPIO1 -> FIOSET = ALL_LED_PINS;
delay(500);
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS; 
delay(500);
}

return 0;
}

void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
	 k++ ;
}

}
 return ; 
}
*/