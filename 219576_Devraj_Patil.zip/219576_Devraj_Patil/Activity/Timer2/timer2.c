#include <lpc17xx.h>
#define LED_PIN(X) (1 << X)


void timer1_delay_us(unsigned int );

void timer1_init(void)
{

	LPC_SC->PCONP |= (1 << 22); //TIMER1 power/clk control enabled
	LPC_SC->PCLKSEL0 |=(0x01 << 12); // cclk=4Mhz
	LPC_TIM2->CTCR = 0x00;
	LPC_TIM2->PR = 2;  
        LPC_TIM2->TCR = (1<<1);
	LPC_TIM2->MCR |= (1<<1)|(1<<0);
}

int main()
 {	
    timer1_init(); 	
	
	LPC_GPIO1->FIODIR |= LED_PIN(24);
	
	timer1_delay_us(2000000);
                                      
    while(1)								  	
	{
	 if(LPC_TIM2->IR & (1<<0))
	 {
	   LPC_GPIO1->FIOPIN ^= LED_PIN(24);
	   LPC_TIM2->IR = 1<<0;
	 }
    }
}

void timer1_delay_us(unsigned int us)
{
   	LPC_TIM2->MR0 = us;
	LPC_TIM2->TCR =(1<<0);
}





