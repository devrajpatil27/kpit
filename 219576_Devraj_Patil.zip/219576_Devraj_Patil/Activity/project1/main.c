										  
//toggle all leds when switch is pressed using polling method

//led pins : [P1.19 - P1.26]
//switch pin : P2.11 for even
//switch pin : P2.10 for odd


#include <LPC17xx.h>
#include <stdint.h>
#include "uart.h"

#define ALL_LED_PINS (0xFF << 19)
#define EVEN_LED_PINS (0x55 << 19)
#define ODD_LED_PINS (0xAA << 19)
#define SWITCH_PIN(X) (1 << X)

void delay(uint32_t ); 

int main(void)
{
LPC_GPIO1 -> FIODIR |= ALL_LED_PINS;	 // output port
LPC_GPIO1 -> FIOCLR = ALL_LED_PINS;		 // removing initial data

LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN(11));
uart_config();
while(1)
{
if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN(11)))== 0 )
{
LPC_GPIO1 -> FIOPIN ^= EVEN_LED_PINS;
uart_str("Blinking Even LEDs \n");
}
if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN(10)))== 0 )
{
LPC_GPIO1 -> FIOPIN ^= ODD_LED_PINS;
uart_str("Blinking Odd LEDs \n");
}
}

return 0;
}

/*void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
 k++ ;
}

}
 return ; 
}	*/

