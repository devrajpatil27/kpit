#include "LPC17xx.h"
#include "lcd.h"
#include <stdio.h>

int main() {
	char date[20]; //array for date 
  	char time[20]; //array for time
	lcd_init();

    LPC_RTC->CIIR = 0;  // Disable all interrupts because we dont need any interrupt
    LPC_RTC->CCR = 1;   // Enable RTC

    LPC_RTC->YEAR = 2022;
    LPC_RTC->MONTH = 11;
    LPC_RTC->DOM = 8;
    LPC_RTC->HOUR = 7;
    LPC_RTC->MIN = 8;
    LPC_RTC->SEC = 1;

    while (1) {
        
		sprintf(date,"date : %d-%d-%d",LPC_RTC->DOM,LPC_RTC->MONTH,LPC_RTC->YEAR);
		lcd_str_write(date);
		lcd_cmd_write(0xC0); //to display the first row of lcd
        
		sprintf(time,"Time : %d-%d-%d",LPC_RTC->HOUR,LPC_RTC->MIN,LPC_RTC->SEC);
		lcd_str_write(time);
		delay(500); //Slowing down Updates to 2 Updates per second
	    lcd_cmd_write(0x01); //to display the second row of lcd
    }
}

