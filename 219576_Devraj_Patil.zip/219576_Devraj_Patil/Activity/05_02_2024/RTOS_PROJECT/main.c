#include "LPC17xx.h"
	   
#define PWM_PIN 2           // P2.2 on LPC1768
#define PWM_PERIOD 1000      // PWM period in microseconds
#define AMBULANCE_FREQ 500   // Frequency of the ambulance sound
#define AMBULANCE_DUTY_CYCLE 500 // Duty cycle for the ambulance sound


 void delay(uint32_t ms)
{
uint32_t i,j,k;
for(i = 0 ; i < ms ; i++)
{
k = 0 ;
for(j = 0 ; j < 3000 ; j++)
{
 k++ ;
}

}
 return ; 
}

void initPWM() {
    // Configure PWM pin as GPIO
    LPC_PINCON->PINSEL4 &= ~(3 << 4);
    LPC_GPIO2->FIODIR |= (1 << PWM_PIN);

    // PWM configuration
    LPC_PWM1->TCR = (1 << 1); // Reset counter
    LPC_PWM1->PR = 0;         // No prescaler
    LPC_PWM1->MCR = (1 << 1); // Reset on match
    LPC_PWM1->MR0 = PWM_PERIOD;
    LPC_PWM1->MR2 = AMBULANCE_DUTY_CYCLE;

    // PWM2 output enabled
    LPC_PWM1->PCR |= (1 << 10);

    // Start PWM
    LPC_PWM1->TCR = (1 << 0) | (1 << 3);
}

int main(void) {
    SystemInit();
    initPWM();

    while (1) {
        // Generate ambulance sound
        LPC_PWM1->MR2 = AMBULANCE_DUTY_CYCLE;
        delay(AMBULANCE_FREQ);
        LPC_PWM1->MR2 = PWM_PERIOD - AMBULANCE_DUTY_CYCLE;
        delay(AMBULANCE_FREQ);
    }

    return 0;
}




























//#include "FreeRTOSConfig.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "queue.h"
//#include "uart.h"
//
//#define BUZZER (1<<27)
//#define SWITCH_PIN(X) (1 << X)
//		
//#define MaxQueueItems 3
//#define QueueItemSize 20
//
//static void MyTask1(void* pvParameters);
//static void MyTask2(void* pvParameters);
//
//xTaskHandle TaskHandle_1;
//xTaskHandle TaskHandle_2;
//
//xQueueHandle MyQH;
//
//#define LED_Task1   (0x02u << 19)	//20LED
//#define LED_Task2   (0x04u << 19)	//22LED
//
//#define LED_PORT LPC_GPIO1->FIOPIN
//
//int main(void)
//{
//	SystemInit();	/* Initialize the controller */
//	uart_init();	/* Initialize the Uart module */	
//	LPC_GPIO1->FIODIR |= 0xff << 19;   //DERECTION SET 19 TO 26
//	LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN(11));//SWITCH PIN
//	LPC_GPIO1->FIODIR|=BUZZER;
//
//	MyQH = xQueueCreate(MaxQueueItems,QueueItemSize);	/* Cretae a queue */
//
//	if(MyQH != 0)
//	{
//		uart_printf("\n\rQueue Created");
//
//		xTaskCreate( MyTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, 3, &TaskHandle_1 );
//		xTaskCreate( MyTask2, "Task2", configMINIMAL_STACK_SIZE, NULL, 2, &TaskHandle_2 );
//
//		vTaskStartScheduler();	/* start the scheduler */
//	}
//	else
//		uart_printf("\n\rQueue not Created");
//
//	while(1);
//
//	return 0;
//}
//
//
//static void MyTask1(void* pvParameters)
//{
//		
//	
//	if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN(11)))!= 0 )
//{
//LPC_GPIO1 -> FIOPIN ^= (1<<20);
//}
//
//	uart_printf("\n\rTask1, SWITCH PRESSED");
//	
//	if(pdTRUE == xQueueSend(MyQH,TxBuffer,100000))
//	{
//		LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rSuccessfully sent the data :");
//		uart_printf(TxBuffer);
//	}
//	else
//	{
//		LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rSending Failed");
//	}
//
//	uart_printf("\n\rExiting task2");
//	vTaskDelete(TaskHandle_2);
//}
//
//
//static void MyTask2(void* pvParameters)
//{
//	char TxBuffer[QueueItemSize]={"Hello KPIT"};
//	
//	LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//
//	uart_printf("\n\rTask2, Filling the data onto queue");
//	
//	if(pdTRUE == xQueueSend(MyQH,TxBuffer,100000))
//	{
//		LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rSuccessfully sent the data :");
//		uart_printf(TxBuffer);
//	}
//	else
//	{
//		LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rSending Failed");
//	}
//
//	uart_printf("\n\rExiting task2");
//	vTaskDelete(TaskHandle_2);
//}


























 //QUEUE TASKS
///* Scheduler include files. */
//#include "FreeRTOSConfig.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "queue.h"
//#include "uart.h"
//#define BUZZER (1<<27)
//#define SWITCH_PIN(X) (1 << X)
//		
//#define MaxQueueItems 3
//#define QueueItemSize 20
//
//static void MyTask1(void* pvParameters);
//static void MyTask2(void* pvParameters);
//
//xTaskHandle TaskHandle_1;
//xTaskHandle TaskHandle_2;
//
//xQueueHandle MyQH;
//
//#define LED_Task1   (0x02u << 19)	//20LED
//#define LED_Task2   (0x04u << 19)	//22LED
//
//#define LED_PORT LPC_GPIO1->FIOPIN
//
//int main(void)
//{
//	SystemInit();			/* Initialize the controller */
//	uart_init();		 /* Initialize the Uart module */	
//	LPC_GPIO1->FIODIR |= 0xff << 19;   //DERECTION SET 19 TO 26
//	LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN(11));//SWITCH PIN
//	LPC_GPIO1->FIODIR|=BUZZER;
//
//	MyQH = xQueueCreate(MaxQueueItems,QueueItemSize);	/* Cretae a queue */
//
//	if(MyQH != 0)
//	{
//		uart_printf("\n\rQueue Created");
//
//		xTaskCreate( MyTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, 3, &TaskHandle_1 );
//		xTaskCreate( MyTask2, "Task2", configMINIMAL_STACK_SIZE, NULL, 2, &TaskHandle_2 );
//
//		vTaskStartScheduler();	/* start the scheduler */
//	}
//	else
//		uart_printf("\n\rQueue not Created");
//
//	while(1);
//
//	return 0;
//}
//
//
//static void MyTask1(void* pvParameters)
//{
//	char RxBuffer[QueueItemSize];
//	
//
//	//LED_PORT = LED_Task1;	  /* Led to indicate the execution of Task1*/
//
//	if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN(11)))!= 0 )
//{
//LPC_GPIO1 -> FIOPIN ^= (1<<20);
//}
//
//	uart_printf("\n\rTask1, SWITCH PRESSED");
//	
//	if(pdTRUE == xQueueReceive(MyQH,RxBuffer,100000))
//	{
//		LED_PORT = LED_Task1;	  /* Led to indicate the execution of Task1*/
//		uart_printf("\n\rBack in task1, Received data : ");
//		uart_printf(RxBuffer);
//
//	}
//	else
//	{
//		LED_PORT = LED_Task1;	  /* Led to indicate the execution of Task1*/
//		uart_printf("\n\rBack in task1, No Data received:");
//	}
//
//	vTaskDelete(TaskHandle_1);
//}
//
//
//static void MyTask2(void* pvParameters)
//{
//	char TxBuffer[QueueItemSize]={"Hello KPIT"};
//	
//	LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//
//	uart_printf("\n\rTask2, Filling the data onto queue");
//	
//	if(pdTRUE == xQueueSend(MyQH,TxBuffer,100000))
//	{
//		LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rSuccessfully sent the data :");
//		uart_printf(TxBuffer);
//	}
//	else
//	{
//		LED_PORT = LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rSending Failed");
//	}
//
//	uart_printf("\n\rExiting task2");
//	vTaskDelete(TaskHandle_2);
//}





















////Multiple task
//
//#include <lpc17xx.h>
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//#include "lcd.h"
//#include "lcd.c"
//
//#define SWITCH_PIN(X) (1 << X)
//
//
//void task1(void *p);
//void task2(void *p);
//void task3(void *p);
//
//int i;
//xTaskHandle t1, t2, t3;  // Declare task handles globally
//
//int main()
//{
//    SystemInit();  // Initialize the system (system clock, PLL, etc.)
//    uart_config();
//    lcd_init();
//   
//    LPC_GPIO1->FIODIR |= (0xFF << 19);
//     LPC_GPIO2 -> FIODIR &= ~(SWITCH_PIN(11));
//
//    xTaskCreate(task1, "T1", 100, NULL, 3, &t1);  // Task1 P=3
//    xTaskCreate(task2, "T2", 100, NULL, 2, &t2);  // Task2 P=2
//    xTaskCreate(task3, "T3", 100, NULL, 1, &t3);  // Task3 P=1
//
//    vTaskStartScheduler();  // Enable Scheduler
//
////    while (1)  // Main Pgm
////    {
////        LPC_GPIO1->FIOSET = (1 << 19);
////        delay(100);
////        LPC_GPIO1->FIOCLR = (1 << 19);
////        delay(100);
////    }
//}
//
//void task1(void *p)  // Task1 -- Toggle LED P1.20
//{
//    while (1)
//    {
//        for (i = 0; i < 10; i++)
//        {
//         LPC_GPIO1->FIOSET|=(1<<19);
//        delay(500);
//        LPC_GPIO1->FIOCLR|=(1<<19);
//        uart_printf("\n\rTask1");
//        vTaskDelay(20000);
//        }
//        vTaskResume(t3);
//        vTaskSuspend(t1);
//    }
//}
//
//void task2(void *p)  // Task2 -- Toggle LED P1.22
//{
//    while (1)
//    {
//        for (i = 0; i < 10; i++)
//        {
//            if(((LPC_GPIO2 -> FIOPIN) & (SWITCH_PIN(11)))!= 0 )
//{
//LPC_GPIO1 -> FIOPIN ^= (1<<20);
//delay(500);
//}
//        uart_printf("\n\rTask2");
//        vTaskDelay(20000);
//        }
//        vTaskSuspend(t2);
//    }
//}
//
//void task3(void *p)  
//{      char message[] = "219576";
//    while (1)
//    {
//        for (i = 0; i < 10; i++)  
//        {
//            lcd_cmd_write(0xC0);
//
//       lcd_str_write(message);
//       uart_printf("\n\r219576");
//
//       delay(1000);
//
//       lcd_cmd_write(0x01);
//        uart_printf("\n\rTask3");
//         uart_printf("\n\rBuzzer on");
//
//        vTaskDelay(20000);
//        }
//        vTaskResume(t2);
//        vTaskSuspend(t3);
//    }
//}
////void task4(void *p){
////while(1){
////for(int i=0;i<4;i++){
////LPC_GPIO1->FIOPIN|=(1<<27);
////        uart_printf("\n\rIn idle state");
////        vTaskDelay(20000);
////}
////}
////}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////#include "LPC17xx.h"
////#include "FreeRTOS.h"
////#include "task.h"
////#include "uart.h"
////#include "lcd.h"
////
////
////#define LED_19    (1 << 19)
////#define LED_20    (1 << 20)
////#define BUZZER_PIN (1 << 1)
////
////
////void task1(void *p);
////void task2(void *p);
////void task3(void *p);
////
////xTaskHandle t1, t2, t3,t4;
////
////
////		
////int i;
////
////int main() {
////    
////	LPC_GPIO1->FIODIR |= LED_19 |LED_20 |BUZZER_PIN;
////	LPC_GPIO1->FIODIR |= (1 << 18);
////
////
////    uart_config();
//////uart_init();
////
////    xTaskCreate(task1, "T1", 100, NULL, 1, &t1);
////    xTaskCreate(task2, "T2", 100, NULL, 2, &t2);
////    xTaskCreate(task3, "T3", 100, NULL, 3, &t3);
////	xTaskCreate(task3, "T4", 100, NULL, 4, &t4);
////
////    vTaskStartScheduler();
////
////    while (1) {
////        LPC_GPIO1->FIOSET = (1 << 20);
////        vTaskDelay(100);
////        LPC_GPIO1->FIOCLR = (1 << 20);
////        vTaskDelay(100);
////    }
////}
////
////void task1(void *p) {
////    while (1) {
////        LPC_GPIO1->FIOPIN^=LED_19;
////		vTaskDelay(100);
////        }
////        
////    }
////
////
////void task2(void *p) {
////    while (1) {
////        if(!(LPC_GPIO1->FIOPIN&=(1<<10)))
////		{
////		  LPC_GPIO1->FIOSET=LED_20;
////		}	else
////		{
////		LPC_GPIO1->FIOCLR=LED_20;
////		}
//////        vTaskSuspend(t2);
////    }
////}
////
////void task3(void *p) {
////       char empID[]="219576";
////    while (1) {
////
//////	lcd_cmd_write("Employee ID");
//////	lcd_cmd_write(empID);
//////
//////        for (i = 0; i < 10; i++) {
//////            uart_str("    Task3...\r\n");
//////        }
//////        vTaskResume(t4);
////    }
////}
////
////
////
////void task4(void *p) {
////    while (1) {
////
////	LPC_GPIO1->FIOSET =BUZZER_PIN;
////			  vTaskDelay(100);
////	LPC_GPIO1->FIOCLR =BUZZER_PIN;
////	vTaskDelay(100);
//////        for (i = 0; i < 10; i++) {
//////            uart_str("  Task4...\r\n");
//////        }
//////        vTaskSuspend(t4);
////    }
////}