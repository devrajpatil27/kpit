//RTOS TASK4

//#include "LPC17xx.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//
//void task1(void *p);
//void task2(void *p);
//void task3(void *p);
//
//xTaskHandle t1, t2, t3;
//int i;
//
//int main() {
//    LPC_GPIO1->FIODIR |= (0xFF << 20);    // Set P1.20, P1.22, P1.24 as output
//
////    uart_config();
//	uart_init();
//
//    xTaskCreate(task1, "T1", 100, NULL, 1, &t1);
//    xTaskCreate(task2, "T2", 100, NULL, 2, &t2);
//    xTaskCreate(task3, "T3", 100, NULL, 3, &t3);
//
//    vTaskStartScheduler();
//
//    while (1) {
//        LPC_GPIO1->FIOSET = (1 << 20);
//        vTaskDelay(100);
//        LPC_GPIO1->FIOCLR = (1 << 20);
//        vTaskDelay(100);
//    }
//}
//
//void task1(void *p) {
//    while (1) {
//        for (i = 0; i < 10; i++) {
//            uart_printf("Task1...\r\n");
//        }
//        vTaskResume(t3);
//    }
//}
//
//void task2(void *p) {
//    while (1) {
//        for (i = 0; i < 10; i++) {
//            uart_printf("  Task2...\r\n");
//        }
//        vTaskSuspend(t2);
//    }
//}
//
//void task3(void *p) {
//    while (1) {
//        for (i = 0; i < 10; i++) {
//            uart_printf("    Task3...\r\n");
//        }
//        vTaskSuspend(t3);
//    }
//}
























//RTOS TASK3
#include <lpc17xx.h>
#include "FreeRTOS.h"
#include "task.h"
#include "uart.h"

void task1(void *p);
void task2(void *p);
void task3(void *p);

int i;
xTaskHandle t1, t2, t3;  // Declare task handles globally


		void delay(unsigned int a)
{
    unsigned int i, j; // 100x 6000/60Mhz = 0.01s--
    for (i = 0; i < a; i++)
        for (j = 0; j < 6000; j++)
            ;
}

int main()
{
    SystemInit();  // Initialize the system (system clock, PLL, etc.)
	//uart_config();
	uart_init();
    LPC_GPIO1->FIODIR |= (0xFF << 19);

    xTaskCreate(task1, "T1", 100, NULL, 3, &t1);  // Task1 P=3
    xTaskCreate(task2, "T2", 100, NULL, 2, &t2);  // Task2 P=2
    xTaskCreate(task3, "T3", 100, NULL, 1, &t3);  // Task3 P=1

    vTaskStartScheduler();  // Enable Scheduler

    while (1)  // Main Pgm
    {
        LPC_GPIO1->FIOSET = (1 << 19);
        delay(100);
        LPC_GPIO1->FIOCLR = (1 << 19);
        delay(100);
    }
}

void task1(void *p)  // Task1 -- Toggle LED P1.20
{
    while (1)
    {
        for (i = 0; i < 10; i++)
        {
            LPC_GPIO1->FIOSET = (1 << 20);
            delay(100);
            LPC_GPIO1->FIOCLR = (1 << 20);
            delay(100);
			uart_printf("Task1...\r\n");
        }
        vTaskResume(t3);
		vTaskSuspend(t1);
    }
}

void task2(void *p)  // Task2 -- Toggle LED P1.22
{
    while (1)
    {
        for (i = 0; i < 10; i++)
        {
            LPC_GPIO1->FIOSET = (1 << 21);
            delay(100);
            LPC_GPIO1->FIOCLR = (1 << 21);
            delay(100);
			uart_printf("Task2...\r\n");
        }
        vTaskSuspend(t2);
    }
}

void task3(void *p)  // Task3 -- Toggle LED P1.24
{
    while (1)
    {
        for (i = 0; i < 10; i++)  // Task P=3
        {
            LPC_GPIO1->FIOSET = (1 << 22);
            delay(100);
            LPC_GPIO1->FIOCLR = (1 << 22);
            delay(100);
			uart_printf("Task3...\r\n");
        }
        vTaskResume(t2);
        vTaskSuspend(t3);
    }
}



















//RTOS TASK2
//#include<lpc17xx.h>
//
///* Scheduler includes. */
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//
//void task1(void *p);
//void task2(void *p);
//void task3(void *p);
//
//void delay(unsigned int a)
//{
//    unsigned int i, j; // 100x 6000/60Mhz = 0.01s--
//    for (i = 0; i < a; i++)
//        for (j = 0; j < 6000; j++)
//            ;
//}
//
//xTaskHandle t1,t2,t3;
//
//int main()
//{
//SystemInit();  // Initialize the system (system clock, PLL, etc.)
//
//LPC_GPIO1->FIODIR |= (0xFF << 19);
//
//xTaskCreate(task1,"T1",100,NULL,1,&t1);				// Task1 P=1
//xTaskCreate(task2,"T2",100,NULL,2,&t2);				// Task2 P=2
//xTaskCreate(task3,"T3",100,NULL,3,&t3);				// Task3 P=3
//
//vTaskStartScheduler();						// Enable Scheduler
//  
//	while(1)					   	// Main Pgm
//	{
//        LPC_GPIO1->FIOSET = (1 << 19);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 19);
//        delay(100);
//	 }
//}
//
//void task1(void *p)		   // Task1 -- Toggle LED P1.20
//{
//	while(1)
//	{
//        LPC_GPIO1->FIOSET = (1 << 20);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 20);
//        delay(100);
//	 }
//}
//
//void task2(void *p)		   // Task2 -- Toggle LED P1.22
//{
//	while(1)
//	{
//        LPC_GPIO1->FIOSET = (1 << 21);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 21);
//        delay(100);
//	 }
//}
//
//void task3(void *p)		   // Task3 -- Toggle LED P1.24
//{
//	while(1)
//	{
//        LPC_GPIO1->FIOSET = (1 << 22);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 22);
//        delay(100);
//	 }
//}























//RTOS TASK1
//#include "LPC17xx.h"
//
///* Scheduler includes. */
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//
//void delay(unsigned int a)
//{
//    unsigned int i, j; // 100x 6000/60Mhz = 0.01s--
//    for (i = 0; i < a; i++)
//        for (j = 0; j < 6000; j++)
//            ;
//}
//
//void task1(void *p);
//xTaskHandle t1;
//int main()
//{
//    SystemInit();  // Initialize the system (system clock, PLL, etc.)
//
//    LPC_GPIO1->FIODIR |= (0xFF << 19);
//
//    xTaskCreate(task1, "T1", configMINIMAL_STACK_SIZE, NULL, 1, &t1);  // Create Task
//
//    vTaskStartScheduler();  // Enable Scheduler
//
//    while (1)  // Main Pgm
//    {
//        LPC_GPIO1->FIOSET = (1 << 19);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 19);
//        delay(100);
//    }
//}
//
//void task1(void *p)  // Task1 -- Toggle LED P1.20
//{
//    while(1)
//    {
//        LPC_GPIO1->FIOSET = (1 << 20);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 20);
//        delay(100);
//    }
//}



















/* 	MULTITASK LED
Scheduler include files. */
//#include "FreeRTOSConfig.h"
//#include "FreeRTOS.h"
//#include "task.h"
//
//#include "uart.h"	
//
///* Local Tasks declaration */
//static void MyTask1(void* pvParameters);
//static void MyTask2(void* pvParameters);
//static void MyTask3(void* pvParameters);
//static void MyIdleTask(void* pvParameters);
//
//#define LED_IdleTask (0x01 << 19)
//#define LED_Task1    (0x02 << 19)
//#define LED_Task2    (0x04 << 19)
//#define LED_Task3    (0x08 << 19)
//
//#define LED_PORT LPC_GPIO1->FIOPIN
//
//int main(void)
//{  
//	SystemInit();			/* Initialize the controller */
//	uart_init();		/* Initialize the Uart module */	
//	LPC_GPIO1->FIODIR |= 0xff << 19;
//
//	/* Create the three tasks with priorities 1,2,3. Only tasks will be created. 
//	 * Tasks will be excecuted once the scheduler is started.
//	 * An idle task is also created, which will be run when there are no tasks in RUN state */ 
//	xTaskCreate( MyTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, 1, NULL );
//	xTaskCreate( MyTask2, "Task2", configMINIMAL_STACK_SIZE, NULL, 2, NULL );
//	xTaskCreate( MyTask3, "Task3", configMINIMAL_STACK_SIZE, NULL, 3, NULL );
//	xTaskCreate( MyIdleTask, "IdleTask", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, NULL );
//
//	uart_printf("\n\rIn the main");
//	
//	vTaskStartScheduler();		/* Start the schedular */
//
//	while(1);
//}
//
//
///* Task1 with priority 1 */
//static void MyTask1(void* pvParameters)
//{
//	while(1)
//	{
//		LED_PORT = 	LED_Task1;	  /* Led to indicate the execution of Task1*/
//		uart_printf("\n\rTask1");  
//		vTaskDelay(5000);
//	}
//}
//
///* Task1 with priority 2 */
//static void MyTask2(void* pvParameters)
//{
//	while(1)
//	{
//		LED_PORT = 	LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rTask2");
//		vTaskDelay(5000);
//	}
//}
//
///* Task1 with priority 3 */
//static void MyTask3(void* pvParameters)
//{
//	while(1)
//	{
//		LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/
//		uart_printf("\n\rTask3");
//		vTaskDelay(5000);
//	}
//}
//
///* Task1 with priority 4 */
//static void MyIdleTask(void* pvParameters)
//{	
//	while(1)
//	{
//		LED_PORT = 	LED_IdleTask;		 /* Led to indicate the execution of Idle Task*/
//		uart_printf("\n\rIn idle state");
//	}									 
//}



















//
////MULTITASK
//#include "FreeRTOSConfig.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//
//
//
///* Local Tasks declaration */
//static void MyTask1(void* pvParameters);
//static void MyTask2(void* pvParameters);
//static void MyTask3(void* pvParameters);
//static void MyIdleTask(void* pvParameters);
//
//
//
//int main(void)
//{
//
//   /* Initialize the Uart module */	
//	SystemInit();
//	uart_init();
//
//
//	/* Create the three tasks with priorities 1,2,3. Only tasks will be created. 
//	 * Tasks will be excecuted once the scheduler is started.
//	 * An idle task is also created, which will be run when there are no tasks in RUN state */ 
//	xTaskCreate( MyTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, 1, NULL );
//	xTaskCreate( MyTask2, "Task2", configMINIMAL_STACK_SIZE, NULL, 2, NULL );
//	xTaskCreate( MyTask3, "Task3", configMINIMAL_STACK_SIZE, NULL, 3, NULL );
//	xTaskCreate( MyIdleTask, "IdleTask", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, NULL );
//
//
//	uart_printf("\n\rIn the main");
//	
//	/* Start the schedular */
//	vTaskStartScheduler();
//
//
//	while(1);
//}
//
//
//
///* Task1 with priority 1 */
//static void MyTask1(void* pvParameters)
//{
//	while(1)
//	{
//		uart_printf("\n\rTask1");
//		vTaskDelay(2000);
//	}
//}
//
//
//static void MyTask2(void* pvParameters)
//{
//	while(1)
//	{
//		uart_printf("\n\rTask2");
//		vTaskDelay(2000);
//	}
//}
//
//
//
//static void MyTask3(void* pvParameters)
//{
//	while(1)
//	{
//		uart_printf("\n\rTask3");
//
//		vTaskDelay(2000);
//	}
//}
//
//
//
//static void MyIdleTask(void* pvParameters)
//{
//
//	while(1)
//	{
//		uart_printf("\n\rIn idle state");
//
//	}
//
//}
//




















////TASK SUSPEND RESUME
//#include "FreeRtOSConfig.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//			
//xTaskHandle TaskHandle_1;
//xTaskHandle TaskHandle_2;
//xTaskHandle TaskHandle_3;
//xTaskHandle TaskHandle_4;
//xTaskHandle TaskHandle_5;
//
//
///* Local Tasks declaration */
//static void MyTask1(void* pvParameters);
//static void MyTask2(void* pvParameters);
//static void MyTask3(void* pvParameters);
//static void MyTask4(void* pvParameters);
//static void MyTask5(void* pvParameters);
//
//#define LED_Task1    (0x01u	<< 19)
//#define LED_Task2    (0x02u	<< 19)
//#define LED_Task3    (0x04u	<< 19)
//#define LED_Task4    (0x08u	<< 19)
//#define LED_Task5    (0x10u	<< 19)
//
//
//#define LED_PORT LPC_GPIO1->FIOPIN
//
//int main(void)
//{
//	SystemInit();			/* Initialize the controller */
//	uart_init();		 /* Initialize the Uart module */	
//	LPC_GPIO1->FIODIR = 0xff<<19;
//
//	/* Create the three tasks with priorities 1,2,3. Only tasks will be created. 
//	 * Tasks will be excecuted once the scheduler is started.
//	 * An idle task is also created, which will be run when there are no tasks in RUN state */ 
//	xTaskCreate( MyTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, 1, &TaskHandle_1);
//	xTaskCreate( MyTask3, "Task3", configMINIMAL_STACK_SIZE, NULL, 3, &TaskHandle_3 );
//
//	uart_printf("\n\rIn main function, invoking scheduler");
//	
//	vTaskStartScheduler();		/* Start the schedular */
//
//	while(1);
//
//	return 0;
//}
//
//
//static void MyTask1(void* pvParameters)
//{
//	LED_PORT = 	LED_Task1;	  /* Led to indicate the execution of Task1*/
//	uart_printf("\n\rTask1, Resuming all tasks");
//	vTaskResume(TaskHandle_2);
//
//	LED_PORT = 	LED_Task1;	  /* Led to indicate the execution of Task1*/
//	uart_printf("\n\rBack in task1, Resuming Task3");
//	vTaskResume(TaskHandle_3);
//	
//	LED_PORT = 	LED_Task1;	  /* Led to indicate the execution of Task1*/
//	uart_printf("\n\rBack in task1, Resuming Task4");
//	vTaskResume(TaskHandle_4);
//
//	LED_PORT = 	LED_Task1;	  /* Led to indicate the execution of Task1*/
//	uart_printf("\n\rBack in task1, Deleting Task1");
//	vTaskDelete(TaskHandle_1);
//}
//
//
//static void MyTask2(void* pvParameters)
//{
//	LED_PORT = 	LED_Task2;	  /* Led to indicate the execution of Task2*/
//	uart_printf("\n\rIn Task2, waiting for some time");
//
//	vTaskDelay(200);
//
//	LED_PORT = 	LED_Task2;	  /* Led to indicate the execution of Task2*/
//	uart_printf("\n\rBack in Task2, , Deleting Task2");
//	
//	vTaskDelete(TaskHandle_2);
//}
//
//
//static void MyTask3(void* pvParameters)
//{
//	LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/	
//	uart_printf("\n\rTask3, creating new tasks 2 and 4");
//
//    /* Create two new tasks 2, 4 */
//	xTaskCreate( MyTask2, "Task2", configMINIMAL_STACK_SIZE, NULL, 2, &TaskHandle_2);
//	xTaskCreate( MyTask4, "Task4", configMINIMAL_STACK_SIZE, NULL, 4, &TaskHandle_4);
//
//	LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/
//	uart_printf("\n\rBack in Task3, Creating Task5");
//
//	xTaskCreate( MyTask5, "Task5", configMINIMAL_STACK_SIZE, NULL, 5, &TaskHandle_5);
//
// 	LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/
//	uart_printf("\n\rFinally in Task3, Deleting Task3");
//
//	vTaskDelete(TaskHandle_3);
//
//}
//
//
//static void MyTask4(void* pvParameters)
//{
//	LED_PORT = 	LED_Task4;	  /* Led to indicate the execution of Task4*/
//	uart_printf("\n\rTask4, Suspending all tasks");
//
//	vTaskSuspend(TaskHandle_2);
//	vTaskSuspend(TaskHandle_3);
//	vTaskSuspend(NULL);
//
//	LED_PORT = 	LED_Task4;	  /* Led to indicate the execution of Task4*/
//	uart_printf("\n\rBack in Task4, Deleting Task4");
//
//    vTaskDelete(TaskHandle_4);
//}
//
//
//static void MyTask5(void* pvParameters)
//{
//	LED_PORT = 	LED_Task5;	  /* Led to indicate the execution of Task4*/
//	uart_printf("\n\rIn Task5, waiting for some time");
//	vTaskDelay(200);
//
//	LED_PORT = 	LED_Task5;	  /* Led to indicate the execution of Task4*/
//	uart_printf("\n\rBack in Task5, Deleting Task5");
//	
//	vTaskDelete(TaskHandle_5);
//}






















//TASK CREATE TASK
//#include "FreeRTOSConfig.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"	
//
//xTaskHandle TH_1;
//xTaskHandle TH_2;
//xTaskHandle TH_3;
//xTaskHandle TH_4;
//xTaskHandle TH_5;
//
//
///* Local Tasks declaration */
//static void MyTask1(void* pvParameters);
//static void MyTask2(void* pvParameters);
//static void MyTask3(void* pvParameters);
//static void MyTask4(void* pvParameters);
//static void MyTask5(void* pvParameters);
//static void MyIdleTask(void* pvParameters);
//
//#define LED_IdleTask (0x01u << 19)
//#define LED_Task1    (0x02u	<< 19)
//#define LED_Task2    (0x04u	<< 19)
//#define LED_Task3    (0x08u	<< 19)
//#define LED_Task4    (0x10u	<< 19)
//#define LED_Task5    (0x20u	<< 19)
//
//#define LED_PORT LPC_GPIO1->FIOPIN
//
//int main(void)
//{
//
//   
//	SystemInit();			/* Initialize the controller */
//	uart_init();		/* Initialize the Uart module */	
//	LPC_GPIO1->FIODIR |= 0xff << 19;
//
//
//	/* Create the three tasks with priorities 1,2,3. Only tasks will be created. 
//	 * Tasks will be excecuted once the scheduler is started.
//	 * An idle task is also created, which will be run when there are no tasks in RUN state */ 
//	xTaskCreate( MyTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, 1, &TH_1);
//	xTaskCreate( MyTask3, "Task3", configMINIMAL_STACK_SIZE, NULL, 3, &TH_3 );
//
//	xTaskCreate( MyIdleTask, "IdleTask", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, NULL );
//
//	uart_printf("\n\rIn main function, invoking scheduler");
//	
//	vTaskStartScheduler();		/* Start the schedular */
//
//	while(1);
//}
//
//
//static void MyTask1(void* pvParameters)
//{
//	LED_PORT = 	LED_Task1;	  /* Led to indicate the execution of Task1*/
//	uart_printf("\n\rIn Task1");
//	vTaskDelete(TH_1);
//}
//
//
//static void MyTask2(void* pvParameters)
//{
//	LED_PORT = 	LED_Task2;	  /* Led to indicate the execution of Task2*/
//	uart_printf("\n\rIn Task2 ");
//	vTaskDelete(TH_2);
//}
//
//
//static void MyTask3(void* pvParameters)
//{
//
//	LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/	
//	uart_printf("\n\rTask3, creating new tasks 2");
//
//    /* Create two new tasks 2, 4 */
//	xTaskCreate( MyTask2, "Task2", configMINIMAL_STACK_SIZE, NULL, 2, &TH_2);
//	uart_printf("\n\rTask3, creating new tasks 4");
//
//	xTaskCreate( MyTask4, "Task4", configMINIMAL_STACK_SIZE, NULL, 4, &TH_4);
//
//	LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/
//	uart_printf("\n\rBack in Task3, Creating Task5");
//
//	xTaskCreate( MyTask5, "Task5", configMINIMAL_STACK_SIZE, NULL, 5, &TH_5);
//
//	LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/
//	uart_printf("\n\rBack in Task3, Exiting task3");
//
//	vTaskDelete(TH_3);
//
//}
//
//
//
//static void MyTask4(void* pvParameters)
//{
//
//	LED_PORT = 	LED_Task4;	  /* Led to indicate the execution of Task4*/
//	uart_printf("\n\rIn Task4");
//	vTaskDelete(TH_4);
//}
//
//
//static void MyTask5(void* pvParameters)
//{
//
//	LED_PORT = 	LED_Task5;	  /* Led to indicate the execution of Task4*/
//	uart_printf("\n\rIn Task5");
//	vTaskDelete(TH_5);
//}
//
//
//static void MyIdleTask(void* pvParameters)
//{	
//	while(1)
//	{
//	    LED_PORT = 	LED_IdleTask;		 /* Led to indicate the execution of Idle Task*/
//		uart_printf("\n\rIn idle state");
//	}									 
//}





















////suspend resume tasks
//#include <lpc17xx.h>
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//
//void task1(void *p);
//void task2(void *p);
//void task3(void *p);
//
////uart_config();
//
//
//int i;
//xTaskHandle t1, t2, t3;  // Declare task handles globally
//
//int main()
//{
//    SystemInit();  // Initialize the system (system clock, PLL, etc.)
//		  uart_init();
//    LPC_GPIO1->FIODIR |= (0xFF << 19);
//
//    xTaskCreate(task1, "T1", 100, NULL, 3, &t1);  // Task1 P=3
//    xTaskCreate(task2, "T2", 100, NULL, 2, &t2);  // Task2 P=2
//    xTaskCreate(task3, "T3", 100, NULL, 1, &t3);  // Task3 P=1
//
//  vTaskStartScheduler();  // Enable Scheduler
//
//    while (1)  // Main Pgm
//    {
//        LPC_GPIO1->FIOSET = (1 << 19);
//         vTaskDelay(100);
//        LPC_GPIO1->FIOCLR = (1 << 19);
//         vTaskDelay(100);
//    }
//}
//
//void task1(void *p)  // Task1 -- Toggle LED P1.20
//{
//    while (1)
//    {
//        for (i = 0; i < 10; i++)
//        {
//            LPC_GPIO1->FIOSET = (1 << 20);
//             vTaskDelay(100);
//            LPC_GPIO1->FIOCLR = (1 << 20);
//             vTaskDelay(100);
//			uart_printf("\n\r Task1");
//        }
//        vTaskResume(t3);
//		vTaskSuspend(t1);
//    }
//}
//
//void task2(void *p)  // Task2 -- Toggle LED P1.22
//{
//    while (1)
//    {
//        for (i = 0; i < 10; i++)
//        {
//            LPC_GPIO1->FIOSET = (1 << 21);
//             delay_ms(100);
//            LPC_GPIO1->FIOCLR = (1 << 21);
//             delay_ms(100);
//			uart_printf("\n\r Task2");
//        }
//        vTaskSuspend(t2);
//    }
//}
//
//void task3(void *p)  // Task3 -- Toggle LED P1.24
//{
//    while (1)
//    {
//        for (i = 0; i < 10; i++)  // Task P=3
//        {
//            LPC_GPIO1->FIOSET = (1 << 22);
//             delay_ms(100);
//            LPC_GPIO1->FIOCLR = (1 << 22);
//            delay_ms(100);
//			uart_printf("\n\rTask3");
//        }
//        vTaskResume(t2);
//        vTaskSuspend(t3);
//    }
//}


















//#include<lpc17xx.h>
//
///* Scheduler includes. */
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//
//void task1(void *p);
//void task2(void *p);
//void task3(void *p);
//
//void delay(unsigned int a)
//{
//    unsigned int i, j; // 100x 6000/60Mhz = 0.01s--
//    for (i = 0; i < a; i++)
//        for (j = 0; j < 6000; j++);
//            
//}
//
//xTaskHandle t1,t2,t3;
//
//int main()
//{
//SystemInit();  // Initialize the system (system clock, PLL, etc.)
//
//LPC_GPIO1->FIODIR |= (0xFF << 19);
//
//xTaskCreate(task1,"T1",100,NULL,1,&t1);				// Task1 P=1
//xTaskCreate(task2,"T2",100,NULL,2,&t2);				// Task2 P=2
//xTaskCreate(task3,"T3",100,NULL,3,&t3);				// Task3 P=3
//
//vTaskStartScheduler();
//						// Enable Scheduler
//  
//	while(1)					   	// Main Pgm
//	{
//        LPC_GPIO1->FIOSET = (1 << 19);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 19);
//        delay(100);
//	 }
//}
//
//void task1(void *p)		   // Task1 -- Toggle LED P1.20
//{
//	while(1)
//	{
//        LPC_GPIO1->FIOSET = (1 << 20);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 20);
//        delay(100);
//	 }
//}
//
//void task2(void *p)		   // Task2 -- Toggle LED P1.22
//{
//	while(1)
//	{
//        LPC_GPIO1->FIOSET = (1 << 21);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 21);
//        delay(100);
//	 }
//}
//
//void task3(void *p)		   // Task3 -- Toggle LED P1.24
//{
//	while(1)
//	{
//        LPC_GPIO1->FIOSET = (1 << 22);
//        delay(100);
//        LPC_GPIO1->FIOCLR = (1 << 22);
//        delay(100);
//	 }
//}















// /* Scheduler include files. */
//
//
//#include "FreeRTOSConfig.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "uart.h"
//	
//
///* Local Tasks declaration */
//static void MyTask1(void* pvParameters);
//static void MyTask2(void* pvParameters);
//static void MyTask3(void* pvParameters);
//static void MyIdleTask(void* pvParameters);
//
//#define LED_IdleTask (0x01 << 19)
//#define LED_Task1    (0x02 << 19)
//#define LED_Task2    (0x04 << 19)
//#define LED_Task3    (0x08 << 19)
//
//
//#define LED_PORT LPC_GPIO1->FIOPIN
//
//int main(void)
//{  
//	SystemInit();		/* Initialize the controller */
//	uart_init();		/* Initialize the Uart module */	
//	LPC_GPIO1->FIODIR |= 0xff << 19;
//
//	/* Create the three tasks with priorities 1,2,3. Only tasks will be created. 
//	 * Tasks will be excecuted once the scheduler is started.
//	 * An idle task is also created, which will be run when there are no tasks in RUN state */ 
//	xTaskCreate( MyTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, 3, NULL ); //XTASKCREATE IS API
//	xTaskCreate( MyTask2, "Task2", configMINIMAL_STACK_SIZE, NULL, 2, NULL );
//	xTaskCreate( MyTask3, "Task3", configMINIMAL_STACK_SIZE, NULL, 1, NULL );	//PRIORITY 3>2>1>NULL
//	xTaskCreate( MyIdleTask, "IdleTask", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, NULL );
//
//	uart_printf("\n\rIn the main");
//	
//	vTaskStartScheduler();		/* Start the schedular */ //IT IS API
//
//	while(1);
////	{
////	vTaskStartScheduler();
////	vTaskDelay(2000);
////	vTaskEndScheduler();
////		uart_printf("\n\rInside while");
////	vTaskDelay(1000);
////
////	}
//}
//
//
///* Task1 with priority 1 */
//static void MyTask1(void* pvParameters)
//{
//	while(1)
//	{
//		LED_PORT = 	LED_Task1;	  /* Led to indicate the execution of Task1*/
//		uart_printf("\n\rTask1");  
//		vTaskDelay(5000);
//	}
//}
//
///* Task1 with priority 2 */
//static void MyTask2(void* pvParameters)
//{
//	while(1)
//	{
//		LED_PORT = 	LED_Task2;	  /* Led to indicate the execution of Task2*/
//		uart_printf("\n\rTask2");
//		vTaskDelay(5000);
//	}
//}
//
///* Task1 with priority 3 */
//static void MyTask3(void* pvParameters)
//{
//	while(1)
//	{
//		LED_PORT = 	LED_Task3;	  /* Led to indicate the execution of Task3*/
//		uart_printf("\n\rTask3");
//		vTaskDelay(5000);
//	}
//}
//
///* Task1 with priority 4 */
//static void MyIdleTask(void* pvParameters)
//{	
//	while(1)
//	{
//		LED_PORT = 	LED_IdleTask;		 /* Led to indicate the execution of Idle Task*/
//		uart_printf("\n\rIn idle state");
//		
//	}									 
//}
