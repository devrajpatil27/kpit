#include <lpc17xx.h>
#include "uart.h"

int main(){
int val=20;
uart_config();
  while(1)
  {
  uart_data('H');
  uart_data('i');
  uart_data('\n');
  uart_str("temperature=  ");
  uart_num(val);
  delay(1000);
  uart_str("\r\n")	 ;
  }

  }