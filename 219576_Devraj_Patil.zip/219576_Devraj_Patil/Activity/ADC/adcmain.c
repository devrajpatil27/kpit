#include <LPC17xx.h>
#include "uart.h"

int main() {
    int val;
    uart_config();
    
    LPC_PINCON->PINSEL1 &= ~(1 << 19);  // Configure P0.25 as AD0.2
    LPC_PINCON->PINSEL1 |= (1 << 18);

    LPC_SC->PCONP |= (1 << 12);  // Enable power to ADC block
    
    LPC_ADC->ADCR = (1 << 2) |      // Select AD0.2
                    (4 << 8) |      // CLKDIV = 4
		            (1 << 16)|      // Burst Mode
                    (1 << 21);      // Enable ADC
    
    while (1) {
        while (!(LPC_ADC->ADGDR & (1 << 31)));  // Wait for the conversion to complete
        
        val = (LPC_ADC->ADGDR >> 4) & 0xFFF;      // Get the 12-bit result
        
        val = val * 10 / 33;
                      
        uart_str("temperature=  ");
        uart_num(val);
        
        delay(1000);
        uart_str("\r\n");
    }
}

