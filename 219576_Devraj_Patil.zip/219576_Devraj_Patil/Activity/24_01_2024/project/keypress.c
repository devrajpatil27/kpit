#include <stdint.h>
#include "lcd.h"
#include "lcd.c"
#include "uart.h"

#define ROW_PINS (0x0F << 4)
#define COL_PINS (0x0F << 0)
int main()	 
{
	  
uint8_t  i,j,val,z;
uint8_t scan[4]= {0xE,0xD,0xB,0x7};
char key[4][4] = {{'0','1','2','3'},
         		   {'4','5','6','7'},
				   {'8','9','A','B'},
				   {'C','D','E','F'}
				  };
lcd_init();
lcd_cmd_write(0x0C); // display on cursor off command
lcd_str_write("Key Pressed : ");


LPC_GPIO2->FIODIR = ROW_PINS;

LPC_GPIO2->FIODIR &= ~COL_PINS;

uart_config();
  
while(1)
{
for(i=0;i<4;i++)
{
LPC_GPIO2->FIOCLR |= ROW_PINS; //clear row lines
LPC_GPIO2->FIOSET |= scan[i] << 4; //activate single row at a time
val = LPC_GPIO2->FIOPIN & COL_PINS;//read column lines
for(j=0;j<4;j++)
{
if(val == scan[j]) break; //if any key is pressed stop scanning  
}
if(val != 0x0F) // if key pressed in the scanned row, print key using lookup table
{
lcd_data_write(key[i][j]);
uart_data(key[i][j]);
uart_str("\n");
lcd_cmd_write(0x10);
delay(100);
}

}			   
	/* if((LPC_UART0->LSR & (1 << 0))){
	  lcd_data_write(LPC_UART0->RBR);
	  lcd_cmd_write(0x10);
	  }	*/
	  z = uart_rx();
	   lcd_data_write(z);
	  lcd_cmd_write(0x10);


}


}
