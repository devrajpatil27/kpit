#include <stdint.h>
#include "lcd.h"
#define ROW_PINS (0x0F << 4)
#define COL_PINS (0x0F << 0)
int main()
{
uint8_t  i,j,val;
uint8_t scan[4]= {0xE,0xD,0xB,0x7};
char key[4][4] = {{'0','1','2','3'},
         		   {'4','5','6','7'},
				   {'8','9','A','B'},
				   {'C','D','E','F'}
				  };
lcd_init();
lcd_cmd_write(0x0C); // display on cursor off command
lcd_str_write("Key Pressed : ");


LPC_GPIO2->FIODIR = ROW_PINS;

LPC_GPIO2->FIODIR &= ~COL_PINS;
  
while(1)
{
for(i=0;i<4;i++)
{
LPC_GPIO2->FIOCLR |= ROW_PINS; //clear row lines
LPC_GPIO2->FIOSET |= scan[i] << 4; //activate single row at a time
val = LPC_GPIO2->FIOPIN & COL_PINS;//read column lines
for(j=0;j<4;j++)
{
if(val == scan[j]) break; //if any key is pressed stop scanning  
}
if(val != 0x0F) // if key pressed in the scanned row, print key using lookup table
{
lcd_data_write(key[i][j]);
lcd_cmd_write(0x10);
delay(100);
}

}

}


}




//#include <stdint.h>
//#include "lcd.h"
//#include "lcd.c"
//#define ROW_PINS (0x0F << 4)  //1111
//#define COL_PINS (0x0F << 0)   //
//int main()
//{
//uint8_t  i,j,val;	//uint8_t-alias name-unsigned integer data type 8-shortint
//uint8_t scan[4]= {0xE,0xD,0xB,0x7};	
//
//char key[4][4] = {{'0','1','2','3'},
//         		   {'4','5','6','7'},
//				   {'8','9','A','B'},
//				   {'C','D','E','F'}
//				  };  
//				   //2d array
//
//lcd_init();	  //initialize the lcd
//
//lcd_cmd_write(0x0C); // display on cursor off command
//lcd_str_write("Key Pressed : ");	 
//
//LPC_GPIO2->FIODIR = ROW_PINS;	//output //port 2 bez in our -high
//LPC_GPIO2->FIODIR &= ~COL_PINS;	   //input
//  
//while(1)
//{
//for(i=0;i<4;i++) //row scan for loop
//{
//LPC_GPIO2->FIOCLR |= ROW_PINS; //clear row lines  -make all rows 0-output rows
//LPC_GPIO2->FIOSET |= scan[i] << 4; //activate single row at a time	-scanning for first row E- if key is pressed you will get output
//val = LPC_GPIO2->FIOPIN & COL_PIN;S//read column lines -	(COL_PIN or 0x0F)
//for(j=0;j<4;j++)	 //column scan for loop
//{
//if(val == scan[j]) break; //if any key is pressed stop scanning  
//}
//if(val != 0x0F) // if key pressed in the scanned row, print key using lookup table
//{
//lcd_data_write(key[i][j]);
//lcd_cmd_write(0x10);//sending to lcd
//delay(100);
//}
//}
//}
//}