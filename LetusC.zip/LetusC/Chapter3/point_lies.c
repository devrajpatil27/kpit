#include<stdio.h>
int main()
{
 float x,y;
 printf("Enter Coordinates\n");
 scanf("%f %f",&x,&y);
 if(x==0.0&&y==0.0)
{
    printf("Point lies on origin\n");
}
 else if (x==0.0&&y>0.0)
{
    printf("Point lies on y-axis\n");
}
 else if(y==0.0&& x>0.0)
{
    printf("Point lies on x-axis\n");
}
return 0;
}