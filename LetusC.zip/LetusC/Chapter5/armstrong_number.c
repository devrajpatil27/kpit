#include <stdio.h>


int isArmstrong(int num) {
    int originalNum, remainder, result = 0, n = 0;

    originalNum = num;

  
    while (originalNum != 0) {
        originalNum /= 10;
        n++;
    }

    originalNum = num;

    
    while (originalNum != 0) {
        remainder = originalNum % 10;
        result += remainder * remainder * remainder;
        originalNum /= 10;
    }

    
    if (result == num)
        return 1;

    return 0;
}

int main() {
    int i;

    printf("Armstrong numbers between 1 and 500 are:\n");

   
    for (i = 1; i <= 500; i++) {
       
        if (isArmstrong(i))
            printf("%d ", i);
    }

    return 0;
}