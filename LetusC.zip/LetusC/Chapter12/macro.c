#define MEAN(x,y) ((x+y)/2.0)
#define ABS(x) ((x<0)?(-1*x):x)
  #define U2L(c) (c+32)
 #define MAX(a,b) ((a>b)?a:b)