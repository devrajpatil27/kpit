// Before compilation, our source code is expanded and stored in
// the file FILENAME.I, so we can open this file and check how our program
// is getting expand.