    #define SI(a,b,c) ((a*b*c)/100.0)
    #define AMOUNT(si,p) (si+p)