#include<stdio.h>

int sum(int num)
{
    if(num > 0)
        return num + sum(num - 1);
    else
        return 0;
}

int main()
{
    printf("Sum of first 25 natural numbers is %d\n", sum(25));

    return 0;
}