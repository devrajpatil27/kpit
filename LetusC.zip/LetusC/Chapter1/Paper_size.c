#include <stdio.h>

int main()
{
    int length = 1189, breadth = 841, tmp, i;
    for (i = 0; i <= 8; i++)
    {
        printf("The size of A(%d) sheet = %d mm x %d mm.\n", i, length, breadth);
        tmp = length;
        length = breadth;
        breadth = tmp / 2;
    }
    return 0;
}