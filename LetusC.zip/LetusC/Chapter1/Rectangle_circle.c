#define PI 3.14159265
#include<stdio.h>
int main()
{
    float length,breadth,radius,area=0;

 printf("Enter the length and breadth of rectangle\n");
 scanf("%f %f",&length,&breadth);

 printf("Enter the radius of circle\n");
 scanf("%f",&radius);

 printf("Area of Rectangle is %f and Perimeter is %f.\n",length*breadth,2*(length+breadth));
 printf("Area of Circle is %f and Circumference is %f.\n",PI*radius*radius,2*PI*radius);
 return 0;
 
}