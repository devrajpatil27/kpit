#include <stdio.h>

int main()
{
    float temp_c, temp_f;
    printf("Enter temp in Fahrenheit\n");
    scanf("%f",&temp_f);
    printf("Temp  in Celsius is %f \n",(temp_f-32)/1.8);
    return 0;
}