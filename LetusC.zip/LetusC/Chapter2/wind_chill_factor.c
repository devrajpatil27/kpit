#include <math.h>
#include <stdio.h>
int main()
{
    printf("Enter temperature and velocity of wind\n");
    float temp, vel, wcf = 0;
    scanf("%f %f", &temp, &vel);
    wcf = 35.74 + 0.6215 * temp + (0.4275 * temp - 35.75) * pow(vel, 0.16);
    printf("Wind Chill factor of Temperature %f and Velocity %f is %f", temp, vel, wcf);
    return 0;
}