#include <stdio.h>
#include <math.h>
int main()
{
    printf("Enter the value of angle\n");
    float angle;
    scanf("%f", &angle);
    printf("The sin %f  = %f.\n", angle,sin(angle));
    printf("The cos %f  = %f.\n", angle, cos(angle));
    printf("The tan %f  = %f.\n", angle, tan(angle));
    printf("The cot %f  = %f.\n", angle, (1 / tan(angle)));
    printf("The cosec %f  = %f.\n", angle, (1 / sin(angle)));
    printf("The sec %f  = %f.\n", angle, (1 / cos(angle)));
    return 0;
}