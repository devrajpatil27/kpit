// Write a C program to check whether a substring is present in a string.

#include <stdio.h>
#include <string.h>

int main()
{
    int c1 = 0, c2 = 0, i, j, flag;

    char str[100], search[100];

    printf("Enter String\n");
    fgets(str, sizeof(str), stdin);

    printf("Enter Sub-string\n");
    fgets(search, sizeof(search), stdin);

    while (str[c1] != '\0')
    {
        c1++;
    }
    c1--;

    while (search[c2] != '\0')
    {
        c2++;
    }
    c2--;

    for (i = 0; i <= c1 - c2; i++)
    {
        for (j = i; j < i + c2; j++)
        {
            flag = 1;
            if (str[j] != search[j - i])
            {
                flag = 0;
                break;
            }
        }
        if (flag == 1)
        {
            break;
        }
    }
    if (flag == 1)
    {
        printf("String exist");
    }
    else
    {
        printf("String does not exist");
    }
    return 0;
}