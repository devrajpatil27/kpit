//Write a C program to find the length of the longest substring of a given string without repeating characters.

#include<stdio.h>
#include<string.h>


int test(char *str, int n) {
    int longest_str_len = 1;  // Length of the longest substring
    int current_substr_len = 1;  // Length of the current substring
    int previous_index, i;  // Variables for iteration
    int temp[256];  // Temporary array to store character indices

    memset(temp, -1, sizeof(int) * 256); // Initialize temp array with -1 (indicating no occurrence)

    temp[str[0]] = 0;  // Set the first character's index in the temp array

    for (i = 1; i < n; i++) {
        previous_index = temp[str[i]]; // Get the previous index of the character

        if (previous_index == -1 || i - current_substr_len > previous_index)
            current_substr_len++;  // If the character is not seen or not part of the current substring, increment the length
        else {
            if (current_substr_len > longest_str_len)
                longest_str_len = current_substr_len; // Update the longest substring length if current is greater

            current_substr_len = i - previous_index; // Update the length of the current substring
        }
        temp[str[i]] = i; // Update the index of the character
    }

    if (current_substr_len > longest_str_len)
        longest_str_len = current_substr_len; // Update the longest substring length if current is greater

    return longest_str_len; // Return the length of the longest substring without repeating characters
}

int main() {
    char str1[80]; 
    int n; 

    printf("Input a string: ");
    scanf("%s",str1);
    n = strlen(str1); 

    if (n > 0) 
        printf("Length of the longest substring without repeating characters: %d", test(str1, n));

    return 0;
}
