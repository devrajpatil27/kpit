//Write a program in C to split strings by space into words.


#include<stdio.h>
#include<string.h>


int main()
{
    char str[100];
    char str2[100][100];
    int i=0,j=0,count=0;

    printf("Enter string\n");
    fgets(str,sizeof(str),stdin);
    int n = strlen(str);

    for( i=0;i<n;i++)
    {
        if(str[i]=='\n'||str[i]==' ')
        {
            str2[count][j]='\0';
            count++;
            j=0;
        }else{
            str2[count][j]=str[i];
            j++;
        }
    }
    for(i=0;i<=count;i++)
    {
        printf("%s\n",str2[i]);

    }

}