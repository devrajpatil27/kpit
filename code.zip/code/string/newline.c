// Write a program in C to print only the string before the new line character.
#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main()
{
    char str[]=" The quick\nbrown fox\njumps over the \nlazy dog. \n";
    int count=0;

    while(isprint(str[count]))
    {
        putchar(str[count]);
        count++;
        if(str[0]=='\n')
        {
            break;
        } 
        if(str[count]=='\n')
        {
            break;
        }         
    }
    return 0;
}


