#include<stdio.h>
#include<string.h>
#define max_size 100

int main()
{
    int vowel=0,consonant=0;
    char str[max_size];
    printf("Enter string\n");
    fgets(str,sizeof(str),stdin);
   
    int len=strlen(str);

    for(int i=0;i<len;i++)
    {
        if(str[i]=='a'||str[i]=='e'||str[i]=='o'||str[i]=='i'||str[i]=='u')
        {
            vowel++;
        }else if(str[i]>='a'&&str[i]<='z'||str[i]>='A'&&str[i]<='Z')
        {
            consonant++;
        }
    }
    printf("Vowel %d\n",vowel);
    printf("Consonant %d\n",consonant);
    return 0;
}