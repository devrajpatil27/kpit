#include<stdio.h>

int main()
{
    int i=0;
    char str1[100],str2[100];

    printf("Enter string\n");
    fgets(str1,sizeof(str1),stdin);
    

    while(str1[i]!='\0')
    {
        str2[i]=str1[i];
        i++;
    }
    str2[i]='\0';
    printf("OriginalString %s",str2);
    printf("CopiedString %s",str2);
    return 0;
}