// Write a program in C to compare two strings without using string library functions.

#include <stdio.h>
#define max_size 100    

int test(char *s1, char *s2)
{
    int flag = 0;
    while (*s1 != '\0' || *s2 != '\0')
    {
        if (*s1 == *s2)
        {
            s1++;
            s2++;
        }
        else if ((*s1 == '\0' && *s2 != '\0') || (*s1 != '\0' && *s2 == '\0') || *s1 != *s2)
        {
            flag = 1;
            break;
        }
    }
    return flag;
}

int main()
{
    int result = 0;

    char str1[max_size], str2[max_size];    

    printf("Enter the strings: \n");

    fgets(str1, sizeof(str1), stdin);
    fgets(str2, sizeof(str2), stdin);

    // printf("string1: %s", str1);
    // printf("string2: %s", str2);

    result = test(str1, str2);

    if (result == 0)
    {
        printf("Strings are equal");
    }
    else if (result == 1)
    {
        printf("Strings are not equal");
    }
    return 0;
}



