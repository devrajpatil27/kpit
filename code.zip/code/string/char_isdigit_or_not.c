 //Write a program in C to check whether a character is a digit or not.
//wrong output
 #include<stdio.h>
 #include<ctype.h>

 int main()
 {
    char ch;
    printf("Enter character\n");
    scanf("%d",&ch);

   if (isdigit(ch)) {
        printf(" The entered character is a digit. \n\n"); 
    } else {
        printf(" The entered character is not a digit. \n\n"); 
    }
    
    return 0;
 }