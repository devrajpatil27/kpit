//Write a program in C to separate individual characters from a string.

#include<stdio.h>

int main()
{
    char str[50];
    int i=0;

    printf("Enter string : ");
    fgets(str,sizeof (str),stdin);
        

    while(str[i]!='\0')
    {
        printf("%c ",str[i]);
        i++;
    }

    printf("\n");
    return 0;
}