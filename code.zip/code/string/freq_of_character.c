//frequency of character

#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int i, count=0;
    char ch;

    printf("Enter string\n");
    fgets(str, sizeof(str), stdin);

    printf("Enter character\n");
    scanf("%c",&ch);

    for (int i = 0; str[i] != '\0'; i++)
    {
        if(ch==str[i])
        {
            count++;
        } 
    }

    printf("Character %c appers %d times\n", ch,count );
    return 0;
}