//Write a C program to count each character in a given string.

#include<stdio.h>
#include<string.h>

int if_char_exists(char c, char p[], int x, int y[]) {
	int i;
	for (i = 0; i <= x; i++) {
		if (p[i] == c) {
			y[i]++; 
			return (1); 
		}
	}
	if (i > x) return (0); 
}

int main() {
	char str1[80], chr[80]; 
	int n, i, x, ctr[80];

	printf("Enter a string: ");
	scanf("%s", str1); 

	n = strlen(str1); 

	chr[0] = str1[0]; 
	ctr[0] = 1; 
	x = 0; 

	for (i = 1; i < n; i++) {
		if (!if_char_exists(str1[i], chr, x, ctr)) { // If character doesn't exist in the new array
			x++; // Increment index for the new array
			chr[x] = str1[i]; // Add the new character to the new array
			ctr[x] = 1; // Initialize its count as 1
		}
	}

	printf("The count of each character in the string %s is \n", str1);
	for (i = 0; i <= x; i++) // Printing the count of each character
		printf("%c\t%d\n", chr[i], ctr[i]);
}
