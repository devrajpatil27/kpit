// Write a program in C to replace the spaces in a string with a specific character.

#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main()
{
    char test;
    char str[100];
    int count=0;

    printf("Enter string\n");
    fgets(str,sizeof(str),stdin);

    printf("Enter Specific character to replace spaces\n");
    scanf("%c",&test);

    while(str[count])
    {
        if(isspace(str[count]))
        {
           str[count]=test;
        }
            putchar(str[count]);
            count++;
    }
    printf("\n");
    return 0;
}