// concate two strings
//not getting output 
#include <stdio.h>
#include <string.h>

int main()
{
    char str1[100];
    char str2[100];
    char len1,len2,i,j;

    printf("Enter string1\n");
    fgets(str1, sizeof(str1), stdin);

    printf("Enter string2\n");
    fgets(str2, sizeof(str2), stdin);

    len1 = strlen(str1);
    len2 = strlen(str2);

    for (int i = 0; i<len1-1; ++i)
    {
        str1[i]=' ';
        i++;
    }

    for (int j = 0; j<len2-1; ++j,++i)
    {
        str1[i]=str2[j];
      
    }

    int k =strlen(str1);
    printf("Concatinated string\n");

    for(i=0;i<k;++i)
    {
        printf("%s",str1[i]);   
    }
    printf("\n");
    return 0;
}