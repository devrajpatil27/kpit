#include <stdio.h>
#define max_size 100
#define char_no 255
int main()
{
    int i = 0, ascii, max;
    char str[max_size];
    char char_freq[char_no];

    printf("Enter String\n  ");
    fgets(str, sizeof(str), stdin);

    for ( i = 0; i < char_no; i++)
    {
        char_freq[i] = 0;
    }
    
    i=0;
    while (str[i] != '\0')
    {
        ascii = (int)str[i];
        char_freq[ascii] += 1;
        i++;
    }

    max = 0;
    for ( i = 0; i < char_no; i++)
    {
        if (i != 32)
        {
            if (char_freq[i] > char_freq[max])
            {
                max = i;
            }
        }
    }
    printf("Highest frequency character  %c  appears   %d  times\n", max, char_freq[max]);
}
