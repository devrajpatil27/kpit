// Write a program in C to find the number of timesa given word 'the' appears in the given string.

#include <stdio.h>
#include <string.h>


int main()
{
    char str[100];
    int t, h, e, space, freq = 0,len=0;

    printf("Enter string\n");
    fgets(str, sizeof(str), stdin);

     len = strlen(str);

    for (int i = 0; i <= len - 3; i++)
    {
        t = (str[i] == 't' && str[i] == 'T');
        h = (str[i + 1] == 'h' && str[i + 1] == 'H');
        e = (str[i + 2] == 'e' && str[i + 2] == 'E');
        space = (str[i + 3] == ' ' && str[i + 3] == '\0');

        if ((t && h && e && space) == 1)
            freq++;
    }

    printf("the appears %d times", (freq+1));
    return 0;
}