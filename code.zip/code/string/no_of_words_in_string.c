//Write a program in C to count the total number of words in a string.
#include<stdio.h>

int main()
{
    char str[100];
    int word=0,i=0;

    printf("Enter string : ");
    fgets(str, sizeof(str),stdin);

    while(str[i]!='\0')
    {
        if(str[i]==' '|| str[i]=='\n'||str[i]=='\t')
        {
            word++;
        }
        i++;
    }
    printf("Total no of words:%d",word);
}