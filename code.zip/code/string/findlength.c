//Write a program in C to input a string and print it.

#include<stdio.h>

int main()
{
    char str[50];

    printf("Enter string\n");
    fgets(str,sizeof(str),stdin);

    printf("Entered string : %s",str);
}