#include<stdio.h>
#include<ctype.h>

int main()
{
    char test;

    printf("Enter character\n");
    scanf("%c",&test);

    if(isupper(test))
    {
        printf("Uppercase");
    }else{
        printf("Not Uppercase");
    }
    return 0;
}