//Write a program in C to count the total number of words in a string.

#include<stdio.h>
#include<string.h>

int main()
{
    char str[100];
    printf("Enter String: ");
    fgets(str,sizeof(str),stdin);
    int l=strlen(str);

    for(int i=l-1;i>=0;i--)
    {
        printf("%c",str[i]);
    }
    printf("\n");
}