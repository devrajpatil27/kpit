//Write a program in C to convert a string to uppercase.

#include<stdio.h>
#include<ctype.h>

int main()
{

    char str[100];
    int count=0,i;
    char str_char;

    printf("Enter String in Lowercase\n");
    fgets(str,sizeof(str),stdin);

    while(str[count])
    {
        str_char=str[count];
        putchar(toupper(str_char));
        count++;
    }
    printf("\n");
    return 0;

}