#include<stdio.h>

int main()
{
    int i=0,alp=0,dig=0,spl_char=0;

    char str[100];
    printf("Enter the string\n");
    fgets(str, sizeof(str),stdin);

    while(str[i]!='\0')
    {
        if((str[i]>='a'&& str[i]<='z') ||  (str[i]>='A'&& str[i]<='Z'))
        {
            alp++;
        }else if (str[i]>='0' && str[i]<='9')
        {
                dig++;
        }else{
        spl_char++;
        }
        i++;
    }
    printf(" alphabets: %d\n Digits: %d\n Special Characters: %d\n",alp,dig,spl_char);
    return 0;


}