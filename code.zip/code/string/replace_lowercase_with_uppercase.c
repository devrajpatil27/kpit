#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to replace lowercase letters with their uppercase counterparts
char * test(char * text) {
    // Check if the string is empty
    if (!text[0])
        return "No string found.";

    char *tt = text;

    // Loop through the string
    while(*tt != '\0') {
        // If the current character is a lowercase letter, convert it to uppercase
        if (*tt >= 'a' && *tt  <= 'z') {
            *tt = *tt + 'A' - 'a'; // Conversion to uppercase
        }
        tt++;
    }
    return text;
}

int main() {
    // Example strings for testing
    //char text[50] = "";
    char text[50] = "Python";
    //char text[50] = "abcdcsd";

    printf("Original string: %s", text);
    printf("\nReplace each lowercase letter with the same uppercase in the said string:\n%s ", test(text));
    return 0;
} 
