#include<stdio.h>
#include<string.h>

int main()
{
    int pos,len,c=0;
    char str[100],sstr[100];

    printf("Enter string \n");
    fgets(str,sizeof(str),stdin);

    printf("Enter position");
    scanf("%d",&pos);

    printf("Enter length");
    scanf("%d",&len);

    while(c<len)
    {
        sstr[c]=str[pos+c-1];
        c++;
    }
    sstr[c]!='\0';
    printf("Extracted string \"%s\"\n",sstr);
    return 0;
}