#include<stdio.h>
#include<ctype.h>

int main()
{
    char test;

    printf("Enter character\n");
    scanf("%c",&test);

    if(isxdigit(test))
    {
        printf("Hexadecimal");
    }else{
        printf("Not hexadecimal");
    }
    return 0;
}