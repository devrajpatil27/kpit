//Write a program in C to read a sentence and replace lowercase 
//characters with uppercase and vice versa.
#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main()
{

char str[100];

printf("Enter string\n");
fgets(str,sizeof(str),stdin);

int i=strlen(str);
int ch =i;

printf("Given string %s\n",str);

for(i=0;i<ch;i++)
{
    ch = islower (str[i])? toupper(str[i]): tolower(str[i]);
    putchar(ch);
}
return 0;
}