//Write a program in C to read a string from the keyboard and sort it using bubble sort.

#include<stdio.h>
#include<string.h>

int main()
{
    int n;
    char str[100][100],temp[100];
    printf("Enter no of strings\n");
    scanf("%d",&n);

    for(int i=0;i<=n;i++)
    {
        fgets(str[i],sizeof(str[i]),stdin);
    }


    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<=n-i;j++)
        {
            if(strcmp(str[j], str[j+1])>0)
            {
                strcpy(temp, str[j]);
                strcpy(str[j], str[j+1]);
                strcpy(str[j+1], temp);
            }

        }
    }
    printf("Strings after sorting\n");
    for(int i=0;i<=n;i++)
    {
        printf("%s\n",str[i]);
    }
}