// Write a program in C to count the number of punctuation characters present in a string.

#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main()
{
    char str[100];
    int count=0,count1=0;

    printf("Enter string\n");
    fgets(str,sizeof(str),stdin);


    while(str[count])
    {
        if(ispunct(str[count]))
        {
          count1++;
        }
        count++;          
    }
    printf("Puncutations: %d",count1);
    printf("\n");
    return 0;
}