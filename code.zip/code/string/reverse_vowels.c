#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Function to swap vowels in a string
char* test(char* text, int l) {
    int i = 0;
    int arr[120] = {0}; // Array to store vowel indexes

    // Setting vowel indexes to 1
    arr['a'] = 1; arr['e'] = 1; arr['i'] = 1; arr['o'] = 1; arr['u'] = 1;
    arr['A'] = 1; arr['E'] = 1; arr['I'] = 1; arr['O'] = 1; arr['U'] = 1;

    while (i < l) {
        // If both characters are vowels, swap them using XOR operations
        if (arr[text[i]] == 1 && arr[text[l]] == 1) {
            text[i] = text[i] ^ text[l];
            text[l] = text[i] ^ text[l];
            text[i] = text[i] ^ text[l];
            i++;
            l--;
        }

        // Move 'i' to the next vowel or end of the string
        while (arr[text[i]] != 1 && i < l) {
            i++;
        }

        // Move 'l' backward to the previous vowel or start of the string
        while (arr[text[l]] != 1 && i < l) {
            l--;
        }
    }
    return text;
}

int main() {
    char string1[80];
    int l;

    printf("Input a string: ");
    scanf("%s", string1);
    l = strlen(string1);

    // Ensure there are at least two characters in the string to process
    if (l - 1 >= 1)
        printf("Check vowel positions in the string after swapping: %s", test(string1, l));
}
