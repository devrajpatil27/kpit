
#include "lpc17xx.h"

int main (void)
{	    		
  uint32_t i,j;
  uint32_t switchStatus;
  LPC_GPIO2->FIODIR = 0x0FF;		
  LPC_GPIO2->FIOCLR = 0x0FF;		
  LPC_GPIO1->FIODIR = 0x00;		
  LPC_GPIO1->FIOCLR = 0x0FF;		

  while(1)
  {
	switchStatus = (LPC_GPIO1->FIOPIN>>0) & 0x01 ;  
		if(switchStatus == 1)                       
       {  
         LPC_GPIO2->FIOPIN = (1<<0);
       }
       else
       {
         LPC_GPIO2->FIOPIN = (0<<0);
       }      
  }
}






