#include "LPC17xx.h"
#define BUZZER_PIN(X) (1 << X)

void delay(int a) {
int i, j;
for (i = 0; i < a; i++)
for (j = 0; j < 6000; j++);
}

int main() {
    int val;
	LPC_GPIO1 -> FIODIR |= BUZZER_PIN(27);
	LPC_PINCON->PINSEL3 &= ~(1 << 4);
    LPC_PINCON->PINSEL3 |= (1 << 5);


	LPC_SC->PCONP |= (1 << 6); 
	LPC_SC->PCLKSEL0 &=~(3<< 12);  

    LPC_PWM1->PR = 3;    
    LPC_PWM1->MR0 = 10000;           
    LPC_PWM1->MCR |= (1 << 1);         
    LPC_PWM1->LER |= (1 << 0);        

    LPC_PWM1->PCR |= (1 << 9);         


    LPC_PWM1->TCR = (1 << 0) | (1 << 3); 

    while (1) {
    LPC_PWM1->MR1 = 2000;   
    LPC_PWM1->LER |= (1 << 1);  
    delay(1000);
    LPC_GPIO0 -> FIOSET = BUZZER_PIN(27);
    delay(1000);
    LPC_GPIO0 -> FIOCLR = BUZZER_PIN(27);
    delay(1000);
    }
}

